"""
База данных персонажей MKX с правильными именами
"""

# === ПОЛНЫЙ СПИСОК ПЕРСОНАЖЕЙ MKX ===

# ПАЛАЧИ (Те, кто делают Fatality/Brutality в 70%+ случаев)
EXECUTORS = {
    # Джейсон Вурхиз
    "Джейсон": {"role": "Палач-Стабильность", "best_round": 2, "winrate": 78.5, "aliases": ["Jason", "Voorhees", "Вурхиз"]},
    "Джейсон Вурхиз": {"role": "Палач-Стабильность", "best_round": 2, "winrate": 78.5, "aliases": ["Jason", "Voorhees"]},
    "Jason": {"role": "Палач-Стабильность", "best_round": 2, "winrate": 78.5, "aliases": ["Джейсон"]},
    
    # Райдэн
    "Райдэн": {"role": "Палач-Затяжной", "best_round": 3, "winrate": 76.2, "aliases": ["Raiden", "Райден"]},
    "Raiden": {"role": "Палач-Затяжной", "best_round": 3, "winrate": 76.2, "aliases": ["Райдэн"]},
    
    # Рептилия
    "Рептилия": {"role": "Палач-Ночной", "best_round": 2, "winrate": 74.8, "aliases": ["Reptile", "Рептайл"]},
    "Reptile": {"role": "Палач-Ночной", "best_round": 2, "winrate": 74.8, "aliases": ["Рептилия"]},
    
    # Триборг
    "Триборг": {"role": "Палач-Универсал", "best_round": 2, "winrate": 79.1, "aliases": ["Triborg", "Триборг Сектор", "Triborg Sektor"]},
    "Triborg": {"role": "Палач-Универсал", "best_round": 2, "winrate": 79.1, "aliases": ["Триборг"]},
    
    # Милина
    "Милина": {"role": "Палач-Скорость", "best_round": 1, "winrate": 77.3, "aliases": ["Mileena", "Милена"]},
    "Mileena": {"role": "Палач-Скорость", "best_round": 1, "winrate": 77.3, "aliases": ["Милина"]},
    
    # Шиннок
    "Шиннок": {"role": "Палач-Контроль", "best_round": 2, "winrate": 73.5, "aliases": ["Shinnok", "Шинок"]},
    "Shinnok": {"role": "Палач-Контроль", "best_round": 2, "winrate": 73.5, "aliases": ["Шиннок"]},
    
    # Коталь Кан
    "Коталь Кан": {"role": "Палач-Мощь", "best_round": 2, "winrate": 75.1, "aliases": ["Kotal Kahn", "Коталь", "Kotal"]},
    "Kotal Kahn": {"role": "Палач-Мощь", "best_round": 2, "winrate": 75.1, "aliases": ["Коталь Кан"]},
    "Коталь": {"role": "Палач-Мощь", "best_round": 2, "winrate": 75.1, "aliases": ["Kotal"]},
    
    # Геррас
    "Геррас": {"role": "Палач-Босс", "best_round": 2, "winrate": 80.2, "aliases": ["Geras", "Герас"]},
    "Geras": {"role": "Палач-Босс", "best_round": 2, "winrate": 80.2, "aliases": ["Геррас"]},
    
    # Синдел
    "Синдел": {"role": "Палач-Вопль", "best_round": 1, "winrate": 74.8, "aliases": ["Sindel", "Синдель"]},
    "Sindel": {"role": "Палач-Вопль", "best_round": 1, "winrate": 74.8, "aliases": ["Синдел"]},
    
    # Ночной Волк
    "Ночной Волк": {"role": "Палач-Шаман", "best_round": 3, "winrate": 72.9, "aliases": ["Nightwolf", "Найтвульф"]},
    "Nightwolf": {"role": "Палач-Шаман", "best_round": 3, "winrate": 72.9, "aliases": ["Ночной Волк"]},
    
    # Спавн
    "Спавн": {"role": "Палач-Ад", "best_round": 2, "winrate": 78.9, "aliases": ["Spawn", "Споун"]},
    "Spawn": {"role": "Палач-Ад", "best_round": 2, "winrate": 78.9, "aliases": ["Спавн"]},
    
    # Терминатор
    "Терминатор": {"role": "Палач-Машина", "best_round": 2, "winrate": 77.5, "aliases": ["Terminator", "T-800", "Терминатор T-800"]},
    "Terminator": {"role": "Палач-Машина", "best_round": 2, "winrate": 77.5, "aliases": ["Терминатор"]},
    
    # Робокоп
    "Робокоп": {"role": "Палач-Закон", "best_round": 2, "winrate": 76.8, "aliases": ["RoboCop", "Робокоп Murphy"]},
    "RoboCop": {"role": "Палач-Закон", "best_round": 2, "winrate": 76.8, "aliases": ["Робокоп"]},
    
    # Рambo
    "Рэмбо": {"role": "Палач-Ветеран", "best_round": 3, "winrate": 75.4, "aliases": ["Rambo", "Рембо"]},
    "Rambo": {"role": "Палач-Ветеран", "best_round": 3, "winrate": 75.4, "aliases": ["Рэмбо"]},
}

# ДОНОРЫ (Те, на ком чаще всего делают добивания)
DONORS = {
    # Соня Блейд
    "Соня Блейд": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "aliases": ["Sonya Blade", "Соня", "Sonya"]},
    "Sonya Blade": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "aliases": ["Соня Блейд"]},
    "Соня": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "aliases": ["Sonya"]},
    "Sonya": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "aliases": ["Соня"]},
    
    # Джакс
    "Джакс": {"best_for": ["Триборг", "Райдэн", "Терминатор"], "donor_rate": 68.3, "aliases": ["Jax", "Джакс Бриггс", "Jax Briggs"]},
    "Jax": {"best_for": ["Триборг", "Райдэн", "Терминатор"], "donor_rate": 68.3, "aliases": ["Джакс"]},
    "Джакс Бриггс": {"best_for": ["Триборг", "Райдэн", "Терминатор"], "donor_rate": 68.3, "aliases": ["Jax Briggs"]},
    "Jax Briggs": {"best_for": ["Триборг", "Райдэн", "Терминатор"], "donor_rate": 68.3, "aliases": ["Джакс Бриггс"]},
    
    # Кэсси Кейдж
    "Кэсси Кейдж": {"best_for": ["Все Палачи"], "donor_rate": 70.1, "aliases": ["Cassie Cage", "Кэсси", "Cassie"]},
    "Cassie Cage": {"best_for": ["Все Палачи"], "donor_rate": 70.1, "aliases": ["Кэсси Кейдж"]},
    "Кэсси": {"best_for": ["Все Палачи"], "donor_rate": 70.1, "aliases": ["Cassie"]},
    "Cassie": {"best_for": ["Все Палачи"], "donor_rate": 70.1, "aliases": ["Кэсси"]},
    
    # Ди'Вора
    "Ди'Вора": {"best_for": ["Сухие матчи"], "donor_rate": 65.4, "aliases": ["D'Vorah", "ДиВора", "DVorah"]},
    "D'Vorah": {"best_for": ["Сухие матчи"], "donor_rate": 65.4, "aliases": ["Ди'Вора", "ДиВора"]},
    "ДиВора": {"best_for": ["Сухие матчи"], "donor_rate": 65.4, "aliases": ["D'Vorah"]},
    "DVorah": {"best_for": ["Сухие матчи"], "donor_rate": 65.4, "aliases": ["Ди'Вора"]},
    
    # Китана
    "Китана": {"best_for": ["Милина", "Синдел"], "donor_rate": 66.8, "aliases": ["Kitana"]},
    "Kitana": {"best_for": ["Милина", "Синдел"], "donor_rate": 66.8, "aliases": ["Китана"]},
    
    # Джейд
    "Джейд": {"best_for": ["Рептилия"], "donor_rate": 64.2, "aliases": ["Jade"]},
    "Jade": {"best_for": ["Рептилия"], "donor_rate": 64.2, "aliases": ["Джейд"]},
    
    # Жаклин Бриггс
    "Жаклин Бриггс": {"best_for": ["Триборг"], "donor_rate": 67.5, "aliases": ["Jacqui Briggs", "Жаклин", "Jacqui"]},
    "Jacqui Briggs": {"best_for": ["Триборг"], "donor_rate": 67.5, "aliases": ["Жаклин Бриггс"]},
    "Жаклин": {"best_for": ["Триборг"], "donor_rate": 67.5, "aliases": ["Jacqui"]},
    "Jacqui": {"best_for": ["Триборг"], "donor_rate": 67.5, "aliases": ["Жаклин"]},
    
    # Кунг Лао
    "Кунг Лао": {"best_for": ["Райдэн"], "donor_rate": 63.8, "aliases": ["Kung Lao", "КунгЛао"]},
    "Kung Lao": {"best_for": ["Райдэн"], "donor_rate": 63.8, "aliases": ["Кунг Лао"]},
    
    # Кунг Джин
    "Кунг Джин": {"best_for": ["Шиннок"], "donor_rate": 62.5, "aliases": ["Kung Jin", "КунгДжин"]},
    "Kung Jin": {"best_for": ["Шиннок"], "donor_rate": 62.5, "aliases": ["Кунг Джин"]},
    
    # Такеда Такахаши
    "Такеда Такахаши": {"best_for": ["Джейсон"], "donor_rate": 68.9, "aliases": ["Takeda Takahashi", "Такеда", "Takeda"]},
    "Takeda Takahashi": {"best_for": ["Джейсон"], "donor_rate": 68.9, "aliases": ["Такеда Такахаши"]},
    "Такеда": {"best_for": ["Джейсон"], "donor_rate": 68.9, "aliases": ["Takeda"]},
    "Takeda": {"best_for": ["Джейсон"], "donor_rate": 68.9, "aliases": ["Такеда"]},
    
    # Кенши
    "Кенши": {"best_for": ["Райдэн"], "donor_rate": 65.7, "aliases": ["Kenshi"]},
    "Kenshi": {"best_for": ["Райдэн"], "donor_rate": 65.7, "aliases": ["Кенши"]},
    
    # Эррон Блэк
    "Эррон Блэк": {"best_for": ["Терминатор"], "donor_rate": 64.3, "aliases": ["Erron Black", "Эррон", "Erron"]},
    "Erron Black": {"best_for": ["Терминатор"], "donor_rate": 64.3, "aliases": ["Эррон Блэк"]},
    "Эррон": {"best_for": ["Терминатор"], "donor_rate": 64.3, "aliases": ["Erron"]},
    "Erron": {"best_for": ["Терминатор"], "donor_rate": 64.3, "aliases": ["Эррон"]},
}

# СЛИВЩИКИ (Те, кто ломают алгоритм - опасны!)
UPSETTERS = {
    # Чужой - самый опасный!
    "Чужой": {"danger_level": "КРИТИЧЕСКИЙ", "note": "Самый опасный аутсайдер! Если справа - НЕ ДОГОНЯТЬ!", "aliases": ["Alien", "Ксеноморф", "Xenomorph"]},
    "Alien": {"danger_level": "КРИТИЧЕСКИЙ", "note": "Самый опасный аутсайдер! Если справа - НЕ ДОГОНЯТЬ!", "aliases": ["Чужой", "Ксеноморф"]},
    "Ксеноморф": {"danger_level": "КРИТИЧЕСКИЙ", "note": "Самый опасный аутсайдер! Если справа - НЕ ДОГОНЯТЬ!", "aliases": ["Alien", "Чужой"]},
    "Xenomorph": {"danger_level": "КРИТИЧЕСКИЙ", "note": "Самый опасный аутсайдер! Если справа - НЕ ДОГОНЯТЬ!", "aliases": ["Alien", "Чужой"]},
    
    # Тремор
    "Тремор": {"danger_level": "ВЫСОКИЙ", "note": "Ломает серии фаталити, выигрывает раунды без добиваний", "aliases": ["Tremor"]},
    "Tremor": {"danger_level": "ВЫСОКИЙ", "note": "Ломает серии фаталити, выигрывает раунды без добиваний", "aliases": ["Тремор"]},
    
    # Лю Кан
    "Лю Кан": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть 3:0 будучи аутсайдером", "aliases": ["Liu Kang", "ЛюКан"]},
    "Liu Kang": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть 3:0 будучи аутсайдером", "aliases": ["Лю Кан"]},
    
    # Скорпион
    "Скорпион": {"danger_level": "СРЕДНИЙ", "note": "Непредсказуем, часто ломает серии", "aliases": ["Scorpion", "Скорп"]},
    "Scorpion": {"danger_level": "СРЕДНИЙ", "note": "Непредсказуем, часто ломает серии", "aliases": ["Скорпион"]},
    
    # Саб-Зиро
    "Саб-Зиро": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть без добиваний", "aliases": ["Sub-Zero", "СабЗиро", "Sub Zero"]},
    "Sub-Zero": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть без добиваний", "aliases": ["Саб-Зиро"]},
    "СабЗиро": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть без добиваний", "aliases": ["Sub-Zero"]},
    "Sub Zero": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть без добиваний", "aliases": ["Саб-Зиро"]},
    
    # Ферра и Торр
    "Ферра и Торр": {"danger_level": "ВЫСОКИЙ", "note": "Непредсказуемый тандем, часто сюрпризы", "aliases": ["Ferra & Torr", "Ferra Torr", "Ферра Торр"]},
    "Ferra & Torr": {"danger_level": "ВЫСОКИЙ", "note": "Непредсказуемый тандем, часто сюрпризы", "aliases": ["Ферра и Торр"]},
    "Ferra Torr": {"danger_level": "ВЫСОКИЙ", "note": "Непредсказуемый тандем, часто сюрпризы", "aliases": ["Ферра и Торр"]},
    "Ферра Торр": {"danger_level": "ВЫСОКИЙ", "note": "Непредсказуемый тандем, часто сюрпризы", "aliases": ["Ferra & Torr"]},
    
    # Кано
    "Кано": {"danger_level": "СРЕДНИЙ", "note": "Хаотичный стиль, ломает паттерны", "aliases": ["Kano"]},
    "Kano": {"danger_level": "СРЕДНИЙ", "note": "Хаотичный стиль, ломает паттерны", "aliases": ["Кано"]},
}

# НЕЙТРАЛЬНЫЕ (Обычные персонажи)
NEUTRAL = {
    # Кратос
    "Кратос": {"note": "PlayStation exclusive", "aliases": ["Kratos"]},
    "Kratos": {"note": "PlayStation exclusive", "aliases": ["Кратос"]},
    
    # Предатор
    "Хищник": {"note": "Guest character", "aliases": ["Predator", "Предатор"]},
    "Predator": {"note": "Guest character", "aliases": ["Хищник"]},
    
    # Горо
    "Горо": {"note": "Boss character", "aliases": ["Goro"]},
    "Goro": {"note": "Boss character", "aliases": ["Горо"]},
    
    # Корнивус Гормак
    "Корнивус Гормак": {"note": "DLC character", "aliases": ["Corrupted Shinnok", "Гормак"]},
    "Corrupted Shinnok": {"note": "DLC character", "aliases": ["Корнивус Гормак"]},
    
    # Ли Мей
    "Ли Мей": {"note": "DLC character", "aliases": ["Li Mei"]},
    "Li Mei": {"note": "DLC character", "aliases": ["Ли Мей"]},
    
    # Бо'Рай Чо
    "Бо'Рай Чо": {"note": "DLC character", "aliases": ["Bo' Rai Cho", "Бо Рай Чо"]},
    "Bo' Rai Cho": {"note": "DLC character", "aliases": ["Бо'Рай Чо"]},
    "Бо Рай Чо": {"note": "DLC character", "aliases": ["Bo' Rai Cho"]},
    
    # Тanya
    "Таня": {"note": "DLC character", "aliases": ["Tanya"]},
    "Tanya": {"note": "DLC character", "aliases": ["Таня"]},
    
    # Тремор (также в UPSETTERS)
    
    # Кибер Саб-Зиро
    "Кибер Саб-Зиро": {"note": "DLC character", "aliases": ["Cyber Sub-Zero"]},
    "Cyber Sub-Zero": {"note": "DLC character", "aliases": ["Кибер Саб-Зиро"]},
}


def get_character_type(name: str) -> tuple:
    """
    Определяет тип персонажа по имени
    
    Returns:
        (type: str, info: dict) - тип и информация о персонаже
    """
    name_clean = name.strip()
    
    # Проверяем Палачей
    for char_name, info in EXECUTORS.items():
        if name_clean.lower() == char_name.lower():
            return ("EXECUTOR", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("EXECUTOR", info)
    
    # Проверяем Доноров
    for char_name, info in DONORS.items():
        if name_clean.lower() == char_name.lower():
            return ("DONOR", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("DONOR", info)
    
    # Проверяем Сливщиков
    for char_name, info in UPSETTERS.items():
        if name_clean.lower() == char_name.lower():
            return ("UPSETTER", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("UPSETTER", info)
    
    # Проверяем Нейтральных
    for char_name, info in NEUTRAL.items():
        if name_clean.lower() == char_name.lower():
            return ("NEUTRAL", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("NEUTRAL", info)
    
    return ("UNKNOWN", {})


def get_all_aliases() -> set:
    """Возвращает все известные алиасы для автодополнения"""
    aliases = set()
    
    for db in [EXECUTORS, DONORS, UPSETTERS, NEUTRAL]:
        for name, info in db.items():
            aliases.add(name)
            if 'aliases' in info:
                aliases.update(info['aliases'])
    
    return aliases


# Список всех персонажей для быстрого поиска
ALL_CHARACTERS = list(EXECUTORS.keys()) + list(DONORS.keys()) + list(UPSETTERS.keys()) + list(NEUTRAL.keys())
