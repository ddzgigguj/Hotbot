"""
Конфигурация бота MKX Strategy v3.0 (Улучшенная версия)
НАСТРОЕНО ПО СТРАТЕГИИ "ЭНЦИКЛОПЕДИЯ АЛГОРИТМОВ v3.0"
"""

import os
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

# === TELEGRAM API CREDENTIALS ===
API_ID = int(os.getenv('TELEGRAM_API_ID', 0))
API_HASH = os.getenv('TELEGRAM_API_HASH', '')
PHONE_NUMBER = os.getenv('PHONE_NUMBER', '')

# === BOT TOKEN ===
BOT_TOKEN = os.getenv('BOT_TOKEN', '')

# === CHANNELS ===
SOURCE_CHANNEL = os.getenv('SOURCE_CHANNEL', 'statamk10')
TARGET_GROUP_ID = int(os.getenv('TARGET_GROUP_ID', 0))
ADMIN_USER_ID = int(os.getenv('ADMIN_USER_ID', 0))

# === BANKROLL MANAGEMENT ===
INITIAL_BANKROLL = float(os.getenv('INITIAL_BANKROLL', 10000))
MAX_DAILY_LOSS_PERCENT = float(os.getenv('MAX_DAILY_LOSS_PERCENT', 20))
MAX_BET_PERCENT = float(os.getenv('MAX_BET_PERCENT', 10))

# === СТРАТЕГИЯ v3.0: ЗОЛОТЫЕ МИНУТЫ (Винрейт 93%+) ===
GOLDEN_MINUTES = [
    "00:10", "00:15", "00:20", "00:25", "00:30", "00:45",
    "01:25", "01:50", "05:55", "07:50"
]

# === СТРАТЕГИЯ v3.0: МЕРТВЫЕ МИНУТЫ (Винрейт < 40% - НЕ СТАВИТЬ!) ===
DEAD_MINUTES = [
    "03:00", "03:30", "04:00", "04:30",  # Полное затишье
    "12:10", "12:40", "13:15",          # Дневные ловушки
    "23:50", "23:55", "23:59"           # Пересчет циклов
]

# === СТРАТЕГИЯ v3.0: МАТЕМАТИКА ===

# Идеальный диапазон КФ на Fatality по v3.0
IDEAL_FATality_KF_RANGE = (2.1, 2.8)

# Минимальный КФ для входа
MIN_FATality_KF = 1.5

# Прогрессия ставок по v3.0 (догон)
BET_PROGRESSION = [1000, 2200, 4800]  # Раунд 1, 2, 3 (СТОП после 3-го)

# Максимальный раунд для догона (СТОП на 3-м согласно v3.0)
MAX_DOGON_ROUND = 3

# === ПОРОГИ УВЕРЕННОСТИ (адаптивные) ===
CONFIDENCE_THRESHOLDS = {
    'strong': 75,
    'medium': 55,
    'weak': 35
}

# === НАСТРОЙКИ МОНИТОРИНГА ===

# Интервал проверки новых сообщений (секунды)
CHECK_INTERVAL = 5

# Время ожидания результатов матча (минуты)
MATCH_WAIT_TIME = 20

# Файл для хранения состояния
STATE_FILE = "bot_state.json"

# Файл базы данных SQLite
DB_FILE = "mkx_stats.db"

# Файл для хранения банкролла
BANKROLL_FILE = "bankroll.json"

# Файл метрик
METRICS_FILE = "metrics.json"

# Логирование
LOG_FILE = "mkx_bot.log"
LOG_LEVEL = "INFO"

# === НАСТРОЙКИ RETRY ===
MAX_RETRIES = 3
RETRY_DELAY = 2  # секунды

# === ML НАСТРОЙКИ ===
ML_MIN_SAMPLES = 50  # Минимальное количество данных для ML
ML_FEATURES = [
    'executor_strength',
    'donor_weakness', 
    'time_pattern_score',
    'recent_wave_factor',
    'odds_value',
    'confidence_score'
]

# === СТАТИСТИКА ===
STATS_DAILY_HOUR = 23  # Час отправки ежедневной статистики
STATS_DAILY_MINUTE = 59

# === ВАЛИДАЦИЯ ===
def validate_config():
    """Проверяет, что все необходимые переменные заданы"""
    required = [
        ('TELEGRAM_API_ID', API_ID),
        ('TELEGRAM_API_HASH', API_HASH),
        ('BOT_TOKEN', BOT_TOKEN),
        ('TARGET_GROUP_ID', TARGET_GROUP_ID),
    ]
    
    missing = [name for name, value in required if not value]
    
    if missing:
        raise ValueError(f"Отсутствуют обязательные переменные окружения: {', '.join(missing)}")
    
    return True
