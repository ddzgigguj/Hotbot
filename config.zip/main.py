"""
MKX Strategy Bot v3.0 - Улучшенная версия
Исправлены критические баги, добавлено управление банкроллом, ML и мониторинг

Автор: AI Assistant
Версия: 3.0.0
"""

import asyncio
import json
import logging
import re
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from telethon import TelegramClient, events
from telethon.tl.types import PeerChannel, PeerChat
import aiohttp

import config
from characters_db import get_character_type, EXECUTORS, DONORS, UPSETTERS
from database import db, MKXDatabase
from bankroll_manager import bankroll
from ml_predictor import ml_predictor
from metrics import metrics

# Проверка конфигурации
config.validate_config()

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# === ФУНКЦИЯ ЗОЛОТЫХ МИНУТ (с диапазоном) ===

def is_golden_minute_range(match_time_str: str) -> Tuple[bool, str]:
    """
    Проверяет, попадает ли время в диапазон золотых минут.
    Возвращает (is_golden, base_golden_minute).
    Например: 00:12 попадает в диапазон 00:10 (00:10-00:14), но 00:15 уже относится к 00:15.
    """
    try:
        hour, minute = map(int, match_time_str.split(':'))
        current_total_minutes = hour * 60 + minute
        
        # Преобразуем золотые минуты в минуты от начала дня и сортируем
        golden_minutes_sorted = []
        for gm in config.GOLDEN_MINUTES:
            gh, gmin = map(int, gm.split(':'))
            golden_minutes_sorted.append((gh * 60 + gmin, gm))
        golden_minutes_sorted.sort()
        
        # Проверяем каждую золотую минуту
        for i, (gm_total, gm_str) in enumerate(golden_minutes_sorted):
            # Определяем конец диапазона (до следующей золотой минуты или +5 минут если последняя)
            if i < len(golden_minutes_sorted) - 1:
                next_gm_total = golden_minutes_sorted[i + 1][0]
                range_end = next_gm_total - 1
            else:
                # Для последней золотой минуты - диапазон 5 минут
                range_end = gm_total + 4
            
            # Проверяем, попадает ли текущее время в диапазон
            if gm_total <= current_total_minutes <= range_end:
                return True, gm_str
        
        return False, ""
    except Exception as e:
        logger.error(f"Ошибка проверки золотой минуты: {e}")
        return False, ""


# === DATA CLASSES ===

@dataclass
class MatchData:
    """Структура данных матча"""
    match_id: str
    league: str
    timestamp: datetime
    player1: str
    player2: str
    p1_match_odds: float
    p2_match_odds: float
    p1_round_odds: float
    p2_round_odds: float
    fatality_odds: float
    brutality_odds: float
    no_finish_odds: float
    time_stats: Dict[str, Tuple[float, float]]
    raw_text: str
    confidence_score: int = 0
    analyzed: bool = False
    analysis_result: Optional[str] = None
    bet_recommendation: Optional[str] = None


@dataclass
class RoundResult:
    """Результат раунда"""
    round_num: int
    winner: str
    finish_type: str
    time_seconds: int
    raw_line: str


@dataclass
class TrackedMatch:
    """Отслеживаемый матч"""
    match_data: MatchData
    sent_analysis_id: Optional[int] = None
    rounds_completed: List[RoundResult] = None
    bet_won: Optional[bool] = None
    won_in_round: Optional[int] = None
    status: str = "pending"
    bet_type: Optional[str] = None
    bet_amount: float = 0
    bet_id: Optional[int] = None
    analysis_text: str = ""
    
    def __post_init__(self):
        if self.rounds_completed is None:
            self.rounds_completed = []


# === TELEGRAM BOT API ===

class TelegramBotAPI:
    """Класс для работы с Bot API с retry-логикой"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}"
    
    async def _make_request(self, method: str, payload: Dict, retries: int = 0) -> Optional[Dict]:
        """Делает запрос к API с retry-логикой"""
        url = f"{self.base_url}/{method}"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=10) as response:
                    metrics.record_api_call(response.status == 200)
                    
                    if response.status == 200:
                        data = await response.json()
                        return data
                    else:
                        error_text = await response.text()
                        logger.error(f"Ошибка API: {error_text}")
                        
                        # Retry если не превысили лимит
                        if retries < config.MAX_RETRIES:
                            await asyncio.sleep(config.RETRY_DELAY * (retries + 1))
                            return await self._make_request(method, payload, retries + 1)
                        
                        return None
        except asyncio.TimeoutError:
            logger.error(f"Таймаут запроса к API")
            if retries < config.MAX_RETRIES:
                await asyncio.sleep(config.RETRY_DELAY * (retries + 1))
                return await self._make_request(method, payload, retries + 1)
            return None
        except Exception as e:
            logger.error(f"Ошибка запроса к API: {e}")
            metrics.record_error('api')
            return None
    
    async def send_message(self, chat_id: int, text: str, parse_mode: str = "HTML") -> Optional[int]:
        """Отправляет сообщение через Bot API"""
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode
        }
        
        data = await self._make_request("sendMessage", payload)
        if data and data.get("ok"):
            return data["result"]["message_id"]
        return None
    
    async def edit_message(self, chat_id: int, message_id: int, text: str, 
                          parse_mode: str = "HTML") -> bool:
        """Редактирует сообщение через Bot API"""
        payload = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": parse_mode
        }
        
        data = await self._make_request("editMessageText", payload)
        return data is not None and data.get("ok", False)
    
    async def send_document(self, chat_id: int, document_path: str, 
                           caption: str = "") -> bool:
        """Отправляет документ через Bot API"""
        try:
            url = f"{self.base_url}/sendDocument"
            
            async with aiohttp.ClientSession() as session:
                with open(document_path, 'rb') as f:
                    data = aiohttp.FormData()
                    data.add_field('chat_id', str(chat_id))
                    data.add_field('document', f, filename=document_path.split('/')[-1])
                    data.add_field('caption', caption)
                    
                    async with session.post(url, data=data, timeout=30) as response:
                        return response.status == 200
        except Exception as e:
            logger.error(f"Ошибка отправки документа: {e}")
            return False


# === PARSER ===

class MKXParser:
    """Улучшенный парсер данных MKX"""
    
    KNOWN_NAMES = [
        "Jax", "Sonya Blade", "Cassie Cage", "Kung Jin", "Kung Lao",
        "Kitana", "Mileena", "Scorpion", "Sub-Zero", "Liu Kang",
        "Raiden", "Kano", "D'Vorah", "Takeda Takahashi", "Kenshi",
        "Erron Black", "Jacqui Briggs", "Tanya", "Reptile", "Ermac",
        "Ferra & Torr", "Kotal Kahn", "Shinnok", "Cetrion", "Geras",
        "Kollector", "Nightwolf", "Sindel", "Spawn", "Terminator",
        "Joker", "RoboCop", "Rambo", "Sheeva", "Fujin", "Rain",
        "Sonya", "Cassie", "KungJin", "KungLao", "SubZero", "Sub-Zero",
        "DVorah", "D'Vorah", "Takeda", "Erron", "Jacqui", "Kotal",
        "Shinnok", "Geras", "Nightwolf", "Sindel", "Spawn", "Terminator",
        "RoboCop", "Rambo", "Sheeva", "Fujin", "Rain", "Cetrion",
        "Джакс", "Соня Блейд", "Соня", "Кэсси Кейдж", "Кэсси",
        "Кунг Джин", "Кунг Лао", "Китана", "Милина", "Скорпион",
        "Саб-Зиро", "СабЗиро", "Лю Кан", "Райдэн", "Кано",
        "Ди'Вора", "ДиВора", "Такеда Такахаши", "Такеда", "Кенши",
        "Эррон Блэк", "Эррон", "Жаклин Бриггс", "Жаклин", "Таня",
        "Рептилия", "Эрмак", "Ферра и Торр", "Ферра Торр", "Коталь Кан",
        "Коталь", "Шиннок", "Сетрион", "Геррас", "Коллектор",
        "Ночной Волк", "Синдел", "Спавн", "Терминатор", "Джокер",
        "Робокоп", "Рэмбо", "Шива", "Фуджин", "Рейн",
        "Jason", "Jason Voorhees", "Джейсон", "Джейсон Вурхиз", "Вурхиз",
        "Predator", "Хищник", "Предатор", "Alien", "Чужой", "Ксеноморф",
        "Xenomorph", "Tremor", "Тремор", "Triborg", "Триборг",
        "Goro", "Горо", "Bo' Rai Cho", "Bo Rai Cho", "Бо'Рай Чо", "Бо Рай Чо",
        "Corrupted Shinnok", "Корнивус Гормак", "Гормак", "Li Mei", "Ли Мей",
        "Cyber Sub-Zero", "Кибер Саб-Зиро"
    ]
    
    @staticmethod
    def extract_player_names(text: str) -> Optional[Tuple[str, str]]:
        """Извлекает имена персонажей из текста"""
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        for line in lines:
            if any(marker in line for marker in ['|', 'P1m', 'P2m', 'FBR', 'FYes', 'TimeStat']):
                continue
            
            for separator in [' - ', ' VS ', ' vs ', ' – ', ' — ']:
                if separator in line:
                    parts = line.split(separator, 1)
                    if len(parts) == 2:
                        p1 = parts[0].strip()
                        p2 = parts[1].strip()
                        
                        if not any(c.isdigit() for c in p1) and not any(c.isdigit() for c in p2):
                            if MKXParser._is_valid_name(p1) and MKXParser._is_valid_name(p2):
                                return (p1, p2)
        
        # Альтернативный метод: хештеги
        hashtag_pattern = r'#([А-Яа-яA-Za-z\s&\-\']+)'
        hashtags = re.findall(hashtag_pattern, text)
        if len(hashtags) >= 2:
            clean_names = []
            for tag in hashtags[:2]:
                name = tag.strip()
                if MKXParser._is_valid_name(name):
                    clean_names.append(name)
            if len(clean_names) == 2:
                return (clean_names[0], clean_names[1])
        
        return None
    
    @staticmethod
    def _is_valid_name(name: str) -> bool:
        """Проверяет, похоже ли имя на персонажа MKX"""
        name_lower = name.lower()
        
        for known in MKXParser.KNOWN_NAMES:
            if name_lower == known.lower():
                return True
            if known.lower() in name_lower or name_lower in known.lower():
                return True
        
        char_type, _ = get_character_type(name)
        if char_type != "UNKNOWN":
            return True
        
        if re.match(r'^[\w\s\-\'&]+$', name):
            return True
        
        return False
    
    @staticmethod
    def parse_match_message(text: str) -> Optional[MatchData]:
        """Парсит сообщение с данными матча"""
        start_time = time.time()
        
        try:
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            
            # Парсим время и ID матча
            header_match = re.search(r'(\d{2}:\d{2})\s+(\d{2}-\d{2}-\d{4})\s+#(N\d+)\s+#(L\d+)', lines[0])
            if not header_match:
                header_match = re.search(r'(\d{2}:\d{2})\s+(\d{2}-\d{2}-\d{4})\s+#(N\d+)', lines[0])
                if header_match:
                    time_str, date_str, match_id = header_match.groups()
                    league = "L1"
                else:
                    return None
            else:
                time_str, date_str, match_id, league = header_match.groups()
            
            timestamp = datetime.strptime(f"{date_str} {time_str}", "%d-%m-%Y %H:%M")
            
            # Извлекаем имена персонажей
            names = MKXParser.extract_player_names(text)
            if not names:
                logger.warning(f"Не удалось распознать имена в матче {match_id}")
                return None
            
            player1, player2 = names
            
            # Парсим коэффициенты
            p1_match_odds, p2_match_odds = 0, 0
            match_odds = re.search(r'P1m\|P2m[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
            if match_odds:
                p1_match_odds = float(match_odds.group(1))
                p2_match_odds = float(match_odds.group(2))
            
            p1_round_odds, p2_round_odds = 0, 0
            round_odds = re.search(r'P1/P2[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
            if round_odds:
                p1_round_odds = float(round_odds.group(1))
                p2_round_odds = float(round_odds.group(2))
            
            fatality_odds = brutality_odds = no_finish_odds = 0
            
            fbr_match = re.search(r'FBR[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
            if fbr_match:
                fatality_odds = float(fbr_match.group(1))
                brutality_odds = float(fbr_match.group(2))
                no_finish_odds = float(fbr_match.group(3))
            else:
                f_match = re.search(r'F[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
                b_match = re.search(r'B[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
                r_match = re.search(r'R[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
                if f_match: fatality_odds = float(f_match.group(1))
                if b_match: brutality_odds = float(b_match.group(1))
                if r_match: no_finish_odds = float(r_match.group(1))
            
            time_stats = {}
            for line in lines:
                stat_match = re.search(r'(\d+\.5)\s*\((\d+\.?\d*)\s*-\s*(\d+\.?\d*)\)', line)
                if stat_match:
                    line_val = stat_match.group(1)
                    over_odds = float(stat_match.group(2))
                    under_odds = float(stat_match.group(3))
                    time_stats[line_val] = (over_odds, under_odds)
            
            parse_time = time.time() - start_time
            metrics.record_match_parsed(parse_time)
            
            return MatchData(
                match_id=match_id,
                league=league,
                timestamp=timestamp,
                player1=player1,
                player2=player2,
                p1_match_odds=p1_match_odds,
                p2_match_odds=p2_match_odds,
                p1_round_odds=p1_round_odds,
                p2_round_odds=p2_round_odds,
                fatality_odds=fatality_odds,
                brutality_odds=brutality_odds,
                no_finish_odds=no_finish_odds,
                time_stats=time_stats,
                raw_text=text
            )
            
        except Exception as e:
            logger.error(f"Ошибка парсинга матча: {e}")
            metrics.record_error('parse')
            return None
    
    @staticmethod
    def parse_round_result(text: str, match_id: str = None) -> Optional[List[RoundResult]]:
        """Парсит результаты раундов из сообщения"""
        try:
            rounds = []
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            
            for line in lines:
                round_match = re.search(r'(\d+)\.\s*(P1|P2)[^FBR]*([FBR])[^\d]*(\d+)', line, re.IGNORECASE)
                if round_match:
                    round_num = int(round_match.group(1))
                    winner = round_match.group(2).upper()
                    finish_type = round_match.group(3).upper()
                    time_seconds = int(round_match.group(4))
                    
                    rounds.append(RoundResult(
                        round_num=round_num,
                        winner=winner,
                        finish_type=finish_type,
                        time_seconds=time_seconds,
                        raw_line=line
                    ))
            
            if rounds:
                metrics.record_rounds_parsed(len(rounds))
            
            return rounds if rounds else None
            
        except Exception as e:
            logger.error(f"Ошибка парсинга результатов раундов: {e}")
            return None


# === ANALYZER ===

class MKXAnalyzer:
    """Улучшенный анализатор с учетом серий, БД и ML"""
    
    def __init__(self):
        self.db = db
    
    def analyze_match(self, match: MatchData) -> Tuple[str, str, int, Dict]:
        """Анализирует матч по стратегии с учетом истории"""
        start_time = time.time()
        
        analysis_parts = []
        confidence_score = 0
        bet_recommendation = "НЕТ СТАВКИ"
        details = {
            'bet_type': None,
            'target_round': None,
            'stop_round': 4,
            'ml_probability': 0,
            'ml_recommendation': 'UNKNOWN'
        }
        
        match_time = match.timestamp.strftime("%H:%M")
        
        # === АНАЛИЗ 1: Проверка на Мертвые минуты ===
        if match_time in config.DEAD_MINUTES:
            analysis_parts.append(f"⚠️ МЕРТВАЯ МИНУТА ({match_time}) - НЕ СТАВИТЬ!")
            return "\n".join(analysis_parts), "🔴 ПРОПУСК", 0, details
        
        # === АНАЛИЗ 2: Проверка на Золотые минуты (с диапазоном) ===
        is_golden, base_golden = is_golden_minute_range(match_time)
        if is_golden:
            if match_time == base_golden:
                analysis_parts.append(f"✨ ЗОЛОТАЯ МИНУТА ({match_time})")
            else:
                analysis_parts.append(f"✨ ЗОЛОТАЯ МИНУТА ({match_time} → {base_golden})")
            confidence_score += 25
        
        # === АНАЛИЗ 3: Проверка серий (волн бритья) ===
        is_shaving_wave, wave_streak = self.db.is_shaving_wave(threshold=3)
        if is_shaving_wave:
            analysis_parts.append(f"🌊 ВОЛНА БРИТЬЯ! {wave_streak} матчей без добиваний")
            analysis_parts.append(f"   💡 Следующий матч ВЕРОЯТНО будет с добиванием!")
            confidence_score += 20
        
        round_streak = self.db.get_recent_no_finish_streak(limit=5)
        if round_streak >= 2:
            analysis_parts.append(f"📊 Серия без добиваний: {round_streak} раундов подряд")
            analysis_parts.append(f"   🎯 ВЕРОЯТНО добивание в ближайших раундах!")
            confidence_score += 15
        
        # === АНАЛИЗ 4: Проверка персонажей ===
        p1_type, p1_info = get_character_type(match.player1)
        p2_type, p2_info = get_character_type(match.player2)
        
        if p2_type == "UPSETTER":
            danger_info = UPSETTERS.get(match.player2, {})
            analysis_parts.append(f"🚨 ОПАСНОСТЬ: {match.player2} - {danger_info.get('note', 'Сливщик!')}")
            confidence_score -= 50
        
        if p1_type == "UPSETTER":
            analysis_parts.append(f"⚠️ {match.player1} слева - риск ложного сигнала")
            confidence_score -= 25
        
        if p1_type == "EXECUTOR" and p2_type == "DONOR":
            executor_info = EXECUTORS.get(match.player1, p1_info)
            donor_info = DONORS.get(match.player2, p2_info)
            best_round = executor_info.get('best_round', 2)
            
            analysis_parts.append(f"🎯 ИДЕАЛЬНАЯ КОМБИНАЦИЯ!")
            analysis_parts.append(f"   Палач: {match.player1} ({executor_info.get('role', 'Палач')})")
            analysis_parts.append(f"   Донор: {match.player2} (шанс добивания: {donor_info.get('donor_rate', 65)}%)")
            analysis_parts.append(f"   Лучший раунд: {best_round}")
            
            details['bet_type'] = 'fatality'
            details['target_round'] = best_round
            confidence_score += 35
            
        elif p1_type == "EXECUTOR":
            executor_info = EXECUTORS.get(match.player1, p1_info)
            best_round = executor_info.get('best_round', 2)
            
            analysis_parts.append(f"✅ Палач слева: {match.player1} ({executor_info.get('role', 'Палач')})")
            analysis_parts.append(f"   Лучший раунд: {best_round}")
            
            details['bet_type'] = 'fatality'
            details['target_round'] = best_round
            confidence_score += 20
        
        elif p2_type == "EXECUTOR":
            analysis_parts.append(f"⚠️ Палач справа: {match.player2} - риск!")
            confidence_score -= 20
        
        # === АНАЛИЗ 5: Проверка КФ ===
        if match.fatality_odds > 0:
            if config.IDEAL_FATality_KF_RANGE[0] <= match.fatality_odds <= config.IDEAL_FATality_KF_RANGE[1]:
                analysis_parts.append(f"💎 ИДЕАЛЬНЫЙ КФ на Fatality: {match.fatality_odds}")
                confidence_score += 15
            elif match.fatality_odds >= config.MIN_FATality_KF:
                analysis_parts.append(f"✅ Допустимый КФ на Fatality: {match.fatality_odds}")
                confidence_score += 10
            else:
                analysis_parts.append(f"❌ Низкий КФ на Fatality: {match.fatality_odds}")
                confidence_score -= 10
        
        if match.brutality_odds > 0:
            if config.IDEAL_FATality_KF_RANGE[0] <= match.brutality_odds <= config.IDEAL_FATality_KF_RANGE[1]:
                analysis_parts.append(f"💎 Отличный КФ на Brutality: {match.brutality_odds}")
                confidence_score += 10
        
        # === АНАЛИЗ 6: Статистика по времени ===
        hour, minute = match.timestamp.hour, match.timestamp.minute
        time_stats = self.db.get_time_pattern_stats(hour, minute)
        if time_stats.get('total_matches', 0) >= 5:
            finish_rate = time_stats.get('any_finish_rate', 0)
            analysis_parts.append(f"📈 Статистика на {match_time}: {finish_rate:.1f}% добиваний")
            if finish_rate >= 70:
                confidence_score += 10
            elif finish_rate <= 40:
                confidence_score -= 15
        
        # === АНАЛИЗ 7: ML Предсказание ===
        try:
            ml_prob, ml_rec, ml_details = ml_predictor.predict(match, {
                'confidence_score': confidence_score,
                'consecutive_losses': bankroll.state.consecutive_losses
            })
            details['ml_probability'] = ml_prob
            details['ml_recommendation'] = ml_rec
            
            analysis_parts.append(f"🤖 ML Вероятность: {ml_prob:.1f}% ({ml_rec})")
            
            # Корректируем confidence на основе ML
            if ml_rec == "STRONG":
                confidence_score += 10
            elif ml_rec == "WEAK":
                confidence_score -= 10
                
        except Exception as e:
            logger.error(f"Ошибка ML предсказания: {e}")
        
        # === АНАЛИЗ 8: Проверка банкролла ===
        can_bet, reason, recommended_amount = bankroll.can_place_bet()
        if not can_bet:
            analysis_parts.append(f"\n🚫 {reason}")
            confidence_score = 0
        else:
            details['recommended_amount'] = recommended_amount
        
        # === ФИНАЛЬНОЕ РЕШЕНИЕ ===
        if confidence_score >= config.CONFIDENCE_THRESHOLDS['strong']:
            bet_recommendation = "🟢 СИЛЬНЫЙ СИГНАЛ"
            if details['bet_type'] and details['target_round']:
                bet_recommendation += f" | Fatality в {details['target_round']} раунде"
                bet_recommendation += f"\n   🛑 STOP если не зашло к 4-му раунду"
        elif confidence_score >= config.CONFIDENCE_THRESHOLDS['medium']:
            bet_recommendation = "🟡 СРЕДНИЙ СИГНАЛ"
            if details['bet_type'] and details['target_round']:
                bet_recommendation += f" | Попробовать {details['target_round']} раунд"
        elif confidence_score >= config.CONFIDENCE_THRESHOLDS['weak']:
            bet_recommendation = "🟠 СЛАБЫЙ СИГНАЛ"
        else:
            bet_recommendation = "🔴 ПРОПУСК"
        
        analysis_parts.append(f"\n📊 Уверенность: {confidence_score}%")
        analysis_parts.append(f"💡 Рекомендация: {bet_recommendation}")
        
        # Записываем время анализа
        analysis_time = time.time() - start_time
        metrics.record_analysis_time(analysis_time)
        
        return "\n".join(analysis_parts), bet_recommendation, confidence_score, details


# === MAIN BOT ===

class MKXBot:
    """Основной класс бота MKX v3.0"""
    
    def __init__(self):
        self.client = TelegramClient('mkx_session', config.API_ID, config.API_HASH)
        self.bot_api = TelegramBotAPI(config.BOT_TOKEN)
        self.parser = MKXParser()
        self.analyzer = MKXAnalyzer()
        self.tracked_matches: Dict[str, TrackedMatch] = {}
        self.db = db
        self.running = True
        self.load_state()
    
    def load_state(self):
        """Загружает состояние бота"""
        try:
            with open(config.STATE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            logger.info("Состояние загружено")
        except FileNotFoundError:
            logger.info("Файл состояния не найден, начинаем с чистого листа")
    
    def save_state(self):
        """Сохраняет состояние бота"""
        try:
            data = {
                'tracked_matches': {},
                'last_update': datetime.now().isoformat()
            }
            with open(config.STATE_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения состояния: {e}")
    
    async def start(self):
        """Запускает бота"""
        print("=" * 60)
        print("🎮 MKX STRATEGY BOT v3.0")
        print("=" * 60)
        print()
        print("📱 Номер:", config.PHONE_NUMBER)
        print("📊 Канал:", config.SOURCE_CHANNEL)
        print("💬 Группа:", config.TARGET_GROUP_ID)
        print()
        
        # Проверяем банкролл
        stats = bankroll.get_stats()
        print(f"💰 Баланс: {stats['current_balance']:.2f} руб.")
        print(f"📈 Прибыль: {stats['net_profit']:+.2f} руб.")
        print()
        
        # Проверяем экстренную остановку
        if bankroll.emergency_stop():
            print("🚨 ЭКСТРЕННАЯ ОСТАНОВКА! Проверьте банкролл.")
            return
        
        await self.client.start(phone=config.PHONE_NUMBER)
        logger.info("Бот запущен и подключен к Telegram")
        
        # Регистрируем обработчики
        self.client.add_event_handler(
            self.on_new_message,
            events.NewMessage(chats=config.SOURCE_CHANNEL)
        )
        
        logger.info(f"✅ Мониторинг канала @{config.SOURCE_CHANNEL}...")
        logger.info(f"✅ Отправка анализа в группу {config.TARGET_GROUP_ID}")
        logger.info("⏳ Ожидание новых матчей...")
        print()
        print("✅ Бот работает! Нажмите Ctrl+C для остановки")
        print()
        
        # Запускаем фоновые задачи
        asyncio.create_task(self.daily_stats_loop())
        asyncio.create_task(self.hourly_check_loop())
        asyncio.create_task(self.ml_training_loop())
        
        # Бесконечный цикл
        while self.running:
            try:
                await asyncio.sleep(config.CHECK_INTERVAL)
                await self.check_match_results()
            except Exception as e:
                logger.error(f"Ошибка в главном цикле: {e}")
                await asyncio.sleep(5)
    
    async def on_new_message(self, event):
        """Обработчик новых сообщений из канала"""
        text = event.message.text
        
        if not text:
            return
        
        metrics.record_message_processed()
        logger.info(f"Получено сообщение: {text[:100]}...")
        
        # Пробуем распарсить как матч
        match_data = self.parser.parse_match_message(text)
        
        if match_data:
            logger.info(f"🎮 Обнаружен матч: {match_data.match_id} - {match_data.player1} vs {match_data.player2}")
            await self.process_new_match(match_data)
        else:
            # Пробуем распарсить как результаты раундов
            match_id_match = re.search(r'#(N\d+)', text)
            if match_id_match:
                match_id = match_id_match.group(1)
                if match_id in self.tracked_matches:
                    rounds = self.parser.parse_round_result(text, match_id)
                    if rounds:
                        await self.process_round_results(match_id, rounds)
    
    async def process_new_match(self, match_data: MatchData):
        """Обрабатывает новый матч"""
        # Сохраняем в БД
        self.db.add_match(match_data)
        
        # Анализируем матч
        analysis, bet_rec, confidence, details = self.analyzer.analyze_match(match_data)
        match_data.confidence_score = confidence
        
        # Фильтр: пропускаем матчи с уверенностью ниже 50%
        if confidence < 50:
            logger.info(f"Матч {match_data.match_id} пропущен (уверенность: {confidence}%)")
            return
        
        # Проверяем банкролл
        can_bet, reason, recommended_amount = bankroll.can_place_bet()
        if not can_bet:
            logger.warning(f"Невозможно сделать ставку: {reason}")
            return
        
        # Формируем сообщение для группы
        message = self.format_analysis_message(match_data, analysis, bet_rec, confidence, details)
        
        # Отправляем в группу через Bot API
        try:
            msg_id = await self.bot_api.send_message(
                config.TARGET_GROUP_ID,
                message,
                parse_mode='HTML'
            )
            
            if msg_id:
                # Определяем сумму ставки
                bet_amount = bankroll.place_bet(recommended_amount)
                
                # Добавляем ставку в БД
                bet_id = None
                if confidence >= 55 and details.get('bet_type'):
                    odds = match_data.fatality_odds if details['bet_type'] == 'fatality' else match_data.brutality_odds
                    bet_id = self.db.add_bet(
                        match_id=match_data.match_id,
                        bet_type=details['bet_type'],
                        predicted_round=details.get('target_round'),
                        amount=bet_amount,
                        odds=odds,
                        dogon_step=bankroll.state.current_dogon_step
                    )
                
                # Сохраняем для отслеживания
                tracked = TrackedMatch(
                    match_data=match_data,
                    sent_analysis_id=msg_id,
                    bet_type=details.get('bet_type'),
                    bet_amount=bet_amount,
                    bet_id=bet_id,
                    analysis_text=analysis
                )
                self.tracked_matches[match_data.match_id] = tracked
                
                # Записываем метрику
                metrics.record_signal(confidence)
                
                logger.info(f"✅ Анализ отправлен для матча {match_data.match_id}, ставка: {bet_amount}")
            else:
                logger.error(f"❌ Не удалось отправить сообщение")
            
        except Exception as e:
            logger.error(f"Ошибка отправки сообщения: {e}")
            metrics.record_error('api')
    
    def format_analysis_message(self, match: MatchData, analysis: str, bet_rec: str, 
                                confidence: int, details: Dict) -> str:
        """Формирует сообщение с анализом"""
        
        p1_type, _ = get_character_type(match.player1)
        p2_type, _ = get_character_type(match.player2)
        
        p1_icon = "🔪" if p1_type == "EXECUTOR" else "💀" if p1_type == "DONOR" else "⚡" if p2_type == "UPSETTER" else "👤"
        p2_icon = "🔪" if p2_type == "EXECUTOR" else "💀" if p2_type == "DONOR" else "⚡" if p2_type == "UPSETTER" else "👤"
        
        # Определяем сумму ставки
        bet_amount = details.get('recommended_amount', bankroll.get_next_bet_amount())
        
        lines = [
            f"🎮 <b>НОВЫЙ МАТЧ</b> #{match.match_id}",
            f"",
            f"{p1_icon} <b>{match.player1}</b> vs {p2_icon} <b>{match.player2}</b>",
            f"🏆 Лига: {match.league}",
            f"🕐 Время: {match.timestamp.strftime('%H:%M %d-%m-%Y')}",
            f"",
            f"📈 <b>Коэффициенты:</b>",
        ]
        
        if match.p1_match_odds > 0:
            lines.append(f"   P1m/P2m: {match.p1_match_odds} | {match.p2_match_odds}")
        if match.p1_round_odds > 0:
            lines.append(f"   P1/P2: {match.p1_round_odds} | {match.p2_round_odds}")
        if match.fatality_odds > 0:
            lines.append(f"   F | B | R: {match.fatality_odds} | {match.brutality_odds} | {match.no_finish_odds}")
        
        lines.extend([
            f"",
            f"📋 <b>АНАЛИЗ СТРАТЕГИИ:</b>",
            f"{analysis}",
            f"",
            f"💰 <b>Сумма ставки:</b> {bet_amount:.0f} руб.",
            f"",
            f"⏳ Ожидание результатов..."
        ])
        
        return "\n".join(lines)
    
    async def process_round_results(self, match_id: str, rounds: List[RoundResult]):
        """Обрабатывает результаты раундов"""
        if match_id not in self.tracked_matches:
            return
        
        tracked = self.tracked_matches[match_id]
        tracked.rounds_completed = rounds
        
        # Сохраняем раунды в БД
        for round_result in rounds:
            self.db.add_round(
                match_id=match_id,
                round_num=round_result.round_num,
                winner=round_result.winner,
                finish_type=round_result.finish_type,
                time_seconds=round_result.time_seconds
            )
        
        # Ищем победный раунд среди первых трех
        won_round = None
        for r in rounds:
            if r.round_num <= 3:
                if tracked.bet_type == 'fatality' and r.finish_type == 'F':
                    won_round = r.round_num
                    break
                elif tracked.bet_type == 'brutality' and r.finish_type == 'B':
                    won_round = r.round_num
                    break
        
        # Определяем, закончился ли матч
        p1_wins = sum(1 for r in rounds if r.winner == 'P1')
        p2_wins = sum(1 for r in rounds if r.winner == 'P2')
        match_ended = (p1_wins == 3 or p2_wins == 3)
        reached_round_4 = any(r.round_num >= 4 for r in rounds)
        
        # Ставим статусы
        if won_round:
            tracked.bet_won = True
            tracked.won_in_round = won_round
            tracked.status = "won"
            
            # Записываем выигрыш в банкролл
            odds = tracked.match_data.fatality_odds if tracked.bet_type == 'fatality' else tracked.match_data.brutality_odds
            bankroll.record_win(tracked.bet_amount, odds, won_round)
            
        elif reached_round_4 or match_ended:
            tracked.bet_won = False
            tracked.status = "lost"
            
            # Записываем проигрыш в банкролл
            bankroll.record_loss(tracked.bet_amount)
        
        # Обновляем результат в БД
        fatality_round = next((r.round_num for r in rounds if r.finish_type == 'F'), None)
        brutality_round = next((r.round_num for r in rounds if r.finish_type == 'B'), None)
        no_finish_count = sum(1 for r in rounds if r.finish_type == 'R')
        
        self.db.update_match_result(
            match_id=match_id,
            result=tracked.status,
            total_rounds=len(rounds),
            fatality_round=fatality_round,
            brutality_round=brutality_round,
            no_finish_count=no_finish_count
        )
        
        # === ИСПРАВЛЕНИЕ: Обновляем результат ставки в БД ===
        if tracked.bet_id:
            profit = 0
            if tracked.status == "won":
                odds = tracked.match_data.fatality_odds if tracked.bet_type == 'fatality' else tracked.match_data.brutality_odds
                profit = tracked.bet_amount * (odds - 1)  # Чистая прибыль
            else:
                profit = -tracked.bet_amount
            
            self.db.update_bet_result(
                bet_id=tracked.bet_id,
                result=tracked.status,
                won_in_round=tracked.won_in_round,
                profit=profit
            )
            
            # Записываем метрику результата
            metrics.record_signal_result(tracked.status)
        
        # Обновляем отображение
        await self.update_analysis_status(tracked)
    
    async def update_analysis_status(self, tracked: TrackedMatch):
        """Обновляет статус анализа в группе"""
        if not tracked.sent_analysis_id:
            return
        
        try:
            # Формируем статус
            if tracked.status == "won":
                checkmarks = "✅" * tracked.won_in_round
                odds = tracked.match_data.fatality_odds if tracked.bet_type == 'fatality' else tracked.match_data.brutality_odds
                profit = tracked.bet_amount * (odds - 1)
                
                status_text = f"\n\n{checkmarks} <b>СТАВКА ЗАШЛА!</b>"
                status_text += f"\n🎯 Раунд: {tracked.won_in_round}"
                status_text += f"\n💰 Прибыль: +{profit:.0f} руб."
                
            elif tracked.status == "lost":
                status_text = f"\n\n❌ <b>СТАВКА НЕ ЗАШЛА</b>"
                status_text += f"\n📉 Убыток: -{tracked.bet_amount:.0f} руб."
                
                # Добавляем информацию о догоне
                next_amount = bankroll.get_next_bet_amount()
                if next_amount > tracked.bet_amount:
                    status_text += f"\n🔄 Следующий догон: {next_amount:.0f} руб."
            else:
                return
            
            # Формируем новое сообщение
            original_message = self.format_analysis_message(
                tracked.match_data,
                tracked.analysis_text,
                "",
                tracked.match_data.confidence_score,
                {}
            )
            
            new_text = original_message.replace("⏳ Ожидание результатов...", status_text)
            
            # Редактируем сообщение
            await self.bot_api.edit_message(
                config.TARGET_GROUP_ID,
                tracked.sent_analysis_id,
                new_text
            )
            
            logger.info(f"✅ Статус обновлен для матча {tracked.match_data.match_id}: {tracked.status}")
            
        except Exception as e:
            logger.error(f"Ошибка обновления статуса: {e}")
    
    async def check_match_results(self):
        """Периодическая проверка результатов"""
        current_time = datetime.now()
        
        for match_id, tracked in list(self.tracked_matches.items()):
            match_time = tracked.match_data.timestamp
            time_diff = (current_time - match_time).total_seconds() / 60
            
            if time_diff > config.MATCH_WAIT_TIME and tracked.status == "pending":
                tracked.status = "lost"
                bankroll.record_loss(tracked.bet_amount)
                
                # Обновляем БД
                if tracked.bet_id:
                    self.db.update_bet_result(
                        bet_id=tracked.bet_id,
                        result='lost',
                        profit=-tracked.bet_amount
                    )
                
                await self.update_analysis_status(tracked)
                logger.info(f"Матч {match_id} помечен как lost по таймауту")
    
    async def send_daily_stats(self):
        """Собирает и отправляет статистику за день"""
        try:
            # Статистика ставок
            bet_stats = self.db.get_bet_stats(days=1)
            
            # Статистика банкролла
            bankroll_stats = bankroll.get_stats()
            
            # Метрики
            perf_stats = metrics.get_performance_stats()
            
            msg = (
                f"📊 <b>Ежедневная статистика</b>\n\n"
                f"<b>Ставки:</b>\n"
                f"• Всего: {bet_stats['total']}\n"
                f"• ✅ Зашло: {bet_stats['wins']}\n"
                f"• ❌ Минусов: {bet_stats['losses']}\n"
                f"• ⏳ В ожидании: {bet_stats['pending']}\n"
                f"• 🎯 Винрейт: {bet_stats['winrate']:.1f}%\n\n"
                f"<b>Финансы:</b>\n"
                f"• Чистая прибыль: {bet_stats['net_profit']:+.2f} руб.\n"
                f"• Текущий баланс: {bankroll_stats['current_balance']:.2f} руб.\n"
                f"• ROI: {bankroll_stats['roi_percent']:+.1f}%\n\n"
                f"<b>Производительность:</b>\n"
                f"• Аптайм: {perf_stats['uptime_hours']:.1f}ч\n"
                f"• Матчей распарсено: {perf_stats['matches_parsed']}\n"
                f"• Ошибок: {perf_stats['errors_count']}"
            )
            
            await self.bot_api.send_message(config.TARGET_GROUP_ID, msg, parse_mode='HTML')
            logger.info("✅ Ежедневная статистика отправлена")
            
        except Exception as e:
            logger.error(f"Ошибка при отправке статистики: {e}")
    
    async def daily_stats_loop(self):
        """Цикл для отправки статистики каждые 24 часа"""
        while self.running:
            try:
                now = datetime.now()
                target = now.replace(hour=config.STATS_DAILY_HOUR, minute=config.STATS_DAILY_MINUTE, second=0)
                
                if target < now:
                    target += timedelta(days=1)
                
                wait_seconds = (target - now).total_seconds()
                logger.info(f"Следующая статистика через {wait_seconds/3600:.1f} часов")
                
                await asyncio.sleep(wait_seconds)
                await self.send_daily_stats()
                
            except Exception as e:
                logger.error(f"Ошибка в цикле статистики: {e}")
                await asyncio.sleep(3600)
    
    async def hourly_check_loop(self):
        """Почасовая проверка банкролла и метрик"""
        while self.running:
            try:
                await asyncio.sleep(3600)  # 1 час
                
                # Проверяем экстренную остановку
                if bankroll.emergency_stop():
                    logger.critical("🚨 ЭКСТРЕННАЯ ОСТАНОВКА! Отправка уведомления...")
                    
                    if config.ADMIN_USER_ID:
                        await self.bot_api.send_message(
                            config.ADMIN_USER_ID,
                            "🚨 <b>ЭКСТРЕННАЯ ОСТАНОВКА БОТА!</b>\n\n" + 
                            bankroll.format_status_message(),
                            parse_mode='HTML'
                        )
                    
                    # Отправляем статус в группу
                    await self.bot_api.send_message(
                        config.TARGET_GROUP_ID,
                        "🚨 <b>Бот остановлен по критериям риска!</b>\n\n" +
                        bankroll.format_status_message(),
                        parse_mode='HTML'
                    )
                    
                    self.running = False
                    break
                
                # Отправляем почасовую статистику
                hourly = metrics.get_hourly_stats()
                if abs(hourly['last_hour_profit']) > 100:
                    await self.bot_api.send_message(
                        config.TARGET_GROUP_ID,
                        f"📊 <b>Почасовая статистика</b>\n\n"
                        f"Прибыль за час: {hourly['last_hour_profit']:+.2f} руб.",
                        parse_mode='HTML'
                    )
                
            except Exception as e:
                logger.error(f"Ошибка в почасовой проверке: {e}")
    
    async def ml_training_loop(self):
        """Цикл для периодического обучения ML"""
        while self.running:
            try:
                # Обучаем раз в сутки
                await asyncio.sleep(86400)
                
                logger.info("Запуск обучения ML модели...")
                ml_predictor.train_if_needed()
                
            except Exception as e:
                logger.error(f"Ошибка в цикле обучения ML: {e}")


def main():
    """Точка входа"""
    bot = MKXBot()
    
    try:
        asyncio.run(bot.start())
    except KeyboardInterrupt:
        print("\n👋 Бот остановлен пользователем")
        bot.save_state()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        raise


if __name__ == "__main__":
    main()
