"""
Метрики и мониторинг для MKX Strategy Bot v3.0
Отслеживание производительности и статистики
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List
from dataclasses import dataclass, asdict, field
from collections import deque
import threading

logger = logging.getLogger(__name__)


@dataclass
class SignalMetrics:
    """Метрики сигналов"""
    total_signals: int = 0
    strong_signals: int = 0
    medium_signals: int = 0
    weak_signals: int = 0
    wins: int = 0
    losses: int = 0
    pending: int = 0
    avg_confidence: float = 0
    avg_processing_time: float = 0


@dataclass
class BotMetrics:
    """Общие метрики бота"""
    start_time: datetime = field(default_factory=datetime.now)
    messages_processed: int = 0
    matches_parsed: int = 0
    rounds_parsed: int = 0
    errors_count: int = 0
    api_calls: int = 0
    api_errors: int = 0
    db_queries: int = 0
    db_errors: int = 0
    
    # Метрики за последний час
    hourly_signals: deque = field(default_factory=lambda: deque(maxlen=60))
    hourly_profit: deque = field(default_factory=lambda: deque(maxlen=60))
    
    # Временные метрики
    parse_times: deque = field(default_factory=lambda: deque(maxlen=100))
    analysis_times: deque = field(default_factory=lambda: deque(maxlen=100))
    db_query_times: deque = field(default_factory=lambda: deque(maxlen=100))


class MetricsCollector:
    """Сборщик метрик бота"""
    
    def __init__(self, metrics_file: str = "metrics.json"):
        self.metrics_file = metrics_file
        self.metrics = BotMetrics()
        self.signal_metrics = SignalMetrics()
        self._lock = threading.Lock()
        self._load_metrics()
    
    def _load_metrics(self):
        """Загружает метрики из файла"""
        try:
            with open(self.metrics_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.signal_metrics = SignalMetrics(**data.get('signals', {}))
                # Восстанавливаем временные метрики
                for pt in data.get('parse_times', []):
                    self.metrics.parse_times.append(pt)
                for at in data.get('analysis_times', []):
                    self.metrics.analysis_times.append(at)
        except (FileNotFoundError, json.JSONDecodeError):
            pass
    
    def _save_metrics(self):
        """Сохраняет метрики в файл"""
        try:
            with open(self.metrics_file, 'w', encoding='utf-8') as f:
                json.dump({
                    'signals': asdict(self.signal_metrics),
                    'parse_times': list(self.metrics.parse_times),
                    'analysis_times': list(self.metrics.analysis_times),
                    'last_updated': datetime.now().isoformat()
                }, f, ensure_ascii=False, indent=2, default=str)
        except Exception as e:
            logger.error(f"Ошибка сохранения метрик: {e}")
    
    # === Методы для записи метрик ===
    
    def record_message_processed(self):
        """Записывает обработанное сообщение"""
        with self._lock:
            self.metrics.messages_processed += 1
    
    def record_match_parsed(self, parse_time: float):
        """Записывает распарсенный матч"""
        with self._lock:
            self.metrics.matches_parsed += 1
            self.metrics.parse_times.append(parse_time)
    
    def record_rounds_parsed(self, count: int):
        """Записывает распарсенные раунды"""
        with self._lock:
            self.metrics.rounds_parsed += count
    
    def record_signal(self, confidence: int, result: str = 'pending'):
        """Записывает сигнал"""
        with self._lock:
            self.signal_metrics.total_signals += 1
            
            if confidence >= 75:
                self.signal_metrics.strong_signals += 1
            elif confidence >= 55:
                self.signal_metrics.medium_signals += 1
            else:
                self.signal_metrics.weak_signals += 1
            
            # Обновляем среднюю уверенность
            n = self.signal_metrics.total_signals
            self.signal_metrics.avg_confidence = (
                (self.signal_metrics.avg_confidence * (n - 1) + confidence) / n
            )
            
            if result == 'won':
                self.signal_metrics.wins += 1
            elif result == 'lost':
                self.signal_metrics.losses += 1
            else:
                self.signal_metrics.pending += 1
            
            self._save_metrics()
    
    def record_signal_result(self, result: str):
        """Обновляет результат сигнала"""
        with self._lock:
            if self.signal_metrics.pending > 0:
                self.signal_metrics.pending -= 1
            
            if result == 'won':
                self.signal_metrics.wins += 1
            elif result == 'lost':
                self.signal_metrics.losses += 1
            
            self._save_metrics()
    
    def record_analysis_time(self, analysis_time: float):
        """Записывает время анализа"""
        with self._lock:
            self.metrics.analysis_times.append(analysis_time)
    
    def record_error(self, error_type: str = 'general'):
        """Записывает ошибку"""
        with self._lock:
            self.metrics.errors_count += 1
            if error_type == 'api':
                self.metrics.api_errors += 1
            elif error_type == 'db':
                self.metrics.db_errors += 1
    
    def record_api_call(self, success: bool = True):
        """Записывает вызов API"""
        with self._lock:
            self.metrics.api_calls += 1
            if not success:
                self.metrics.api_errors += 1
    
    def record_db_query(self, query_time: float):
        """Записывает запрос к БД"""
        with self._lock:
            self.metrics.db_queries += 1
            self.metrics.db_query_times.append(query_time)
    
    def record_hourly_profit(self, profit: float):
        """Записывает прибыль за час"""
        with self._lock:
            self.metrics.hourly_profit.append(profit)
    
    # === Методы для получения метрик ===
    
    def get_signal_stats(self) -> Dict:
        """Возвращает статистику сигналов"""
        with self._lock:
            finished = self.signal_metrics.wins + self.signal_metrics.losses
            winrate = (self.signal_metrics.wins / finished * 100) if finished > 0 else 0
            
            return {
                'total': self.signal_metrics.total_signals,
                'strong': self.signal_metrics.strong_signals,
                'medium': self.signal_metrics.medium_signals,
                'weak': self.signal_metrics.weak_signals,
                'wins': self.signal_metrics.wins,
                'losses': self.signal_metrics.losses,
                'pending': self.signal_metrics.pending,
                'winrate': winrate,
                'avg_confidence': self.signal_metrics.avg_confidence,
                'avg_processing_time': self.signal_metrics.avg_processing_time
            }
    
    def get_performance_stats(self) -> Dict:
        """Возвращает метрики производительности"""
        with self._lock:
            avg_parse = sum(self.metrics.parse_times) / len(self.metrics.parse_times) \
                        if self.metrics.parse_times else 0
            avg_analysis = sum(self.metrics.analysis_times) / len(self.metrics.analysis_times) \
                          if self.metrics.analysis_times else 0
            avg_db_query = sum(self.metrics.db_query_times) / len(self.metrics.db_query_times) \
                          if self.metrics.db_query_times else 0
            
            return {
                'uptime_hours': (datetime.now() - self.metrics.start_time).total_seconds() / 3600,
                'messages_processed': self.metrics.messages_processed,
                'matches_parsed': self.metrics.matches_parsed,
                'rounds_parsed': self.metrics.rounds_parsed,
                'avg_parse_time_ms': avg_parse * 1000,
                'avg_analysis_time_ms': avg_analysis * 1000,
                'avg_db_query_time_ms': avg_db_query * 1000,
                'errors_count': self.metrics.errors_count,
                'api_success_rate': (1 - self.metrics.api_errors / max(self.metrics.api_calls, 1)) * 100,
                'db_success_rate': (1 - self.metrics.db_errors / max(self.metrics.db_queries, 1)) * 100
            }
    
    def get_hourly_stats(self) -> Dict:
        """Возвращает почасовую статистику"""
        with self._lock:
            profits = list(self.metrics.hourly_profit)
            return {
                'last_hour_profit': profits[-1] if profits else 0,
                'last_6h_profit': sum(profits[-6:]) if len(profits) >= 6 else sum(profits),
                'last_24h_profit': sum(profits[-24:]) if len(profits) >= 24 else sum(profits),
                'hourly_average': sum(profits) / len(profits) if profits else 0
            }
    
    def get_all_metrics(self) -> Dict:
        """Возвращает все метрики"""
        return {
            'signals': self.get_signal_stats(),
            'performance': self.get_performance_stats(),
            'hourly': self.get_hourly_stats(),
            'timestamp': datetime.now().isoformat()
        }
    
    def format_metrics_message(self) -> str:
        """Форматирует сообщение с метриками"""
        signals = self.get_signal_stats()
        perf = self.get_performance_stats()
        hourly = self.get_hourly_stats()
        
        return f"""
📊 <b>МЕТРИКИ БОТА</b>

🎯 <b>Сигналы:</b>
• Всего: {signals['total']} | 🟢 {signals['strong']} | 🟡 {signals['medium']} | 🟠 {signals['weak']}
• Результаты: ✅ {signals['wins']} | ❌ {signals['losses']} | ⏳ {signals['pending']}
• Винрейт: <b>{signals['winrate']:.1f}%</b>
• Средняя уверенность: {signals['avg_confidence']:.1f}%

⚡ <b>Производительность:</b>
• Аптайм: {perf['uptime_hours']:.1f}ч
• Сообщений: {perf['messages_processed']}
• Матчей: {perf['matches_parsed']} | Раундов: {perf['rounds_parsed']}
• Ошибок: {perf['errors_count']}

💰 <b>Прибыль:</b>
• Последний час: {hourly['last_hour_profit']:+.2f} руб.
• Последние 6ч: {hourly['last_6h_profit']:+.2f} руб.
• Последние 24ч: {hourly['last_24h_profit']:+.2f} руб.

⏱ <b>Время обработки:</b>
• Парсинг: {perf['avg_parse_time_ms']:.1f}мс
• Анализ: {perf['avg_analysis_time_ms']:.1f}мс
• БД запрос: {perf['avg_db_query_time_ms']:.1f}мс
"""


# Глобальный экземпляр сборщика метрик
metrics = MetricsCollector()
