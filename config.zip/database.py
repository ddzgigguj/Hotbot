"""
SQLite база данных для отслеживания статистики и серий MKX v3.0
Улучшенная версия с пулом соединений и оптимизациями
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from contextlib import contextmanager
import threading
import logging

logger = logging.getLogger(__name__)

DB_FILE = "mkx_stats.db"


@dataclass
class RoundHistory:
    """История раундов для отслеживания серий"""
    match_id: str
    round_num: int
    winner: str
    finish_type: str  # F, B, R
    timestamp: datetime


@dataclass
class MatchResult:
    """Результат матча"""
    match_id: str
    player1: str
    player2: str
    total_rounds: int
    fatality_round: Optional[int]
    brutality_round: Optional[int]
    no_finish_count: int
    result: str  # 'won', 'lost', 'pending'
    timestamp: datetime


@dataclass
class BetRecord:
    """Запись о ставке"""
    id: int
    match_id: str
    bet_type: str
    predicted_round: Optional[int]
    amount: float
    odds: float
    result: str
    won_in_round: Optional[int]
    profit: float
    created_at: datetime


class ConnectionPool:
    """Пул соединений с SQLite"""
    
    def __init__(self, db_file: str, max_connections: int = 5):
        self.db_file = db_file
        self.max_connections = max_connections
        self._pool = []
        self._lock = threading.Lock()
        self._local = threading.local()
    
    @contextmanager
    def get_connection(self):
        """Получает соединение из пула"""
        conn = None
        try:
            # Проверяем, есть ли уже соединение для этого потока
            if hasattr(self._local, 'connection') and self._local.connection:
                conn = self._local.connection
            else:
                with self._lock:
                    if self._pool:
                        conn = self._pool.pop()
                    else:
                        conn = sqlite3.connect(self.db_file, check_same_thread=False)
                        conn.row_factory = sqlite3.Row
                self._local.connection = conn
            
            yield conn
            
        except Exception as e:
            logger.error(f"Ошибка в соединении БД: {e}")
            if conn:
                conn.rollback()
            raise
    
    def release_connection(self, conn):
        """Возвращает соединение в пул"""
        with self._lock:
            if len(self._pool) < self.max_connections:
                self._pool.append(conn)
            else:
                conn.close()


class MKXDatabase:
    """База данных для хранения статистики MKX v3.0"""
    
    def __init__(self, db_file: str = DB_FILE):
        self.db_file = db_file
        self.pool = ConnectionPool(db_file)
        self.init_database()
    
    def init_database(self):
        """Инициализирует таблицы БД"""
        with self.pool.get_connection() as conn:
            cursor = conn.cursor()
            
            # Таблица матчей
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS matches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    match_id TEXT UNIQUE NOT NULL,
                    player1 TEXT NOT NULL,
                    player2 TEXT NOT NULL,
                    league TEXT,
                    match_time TIMESTAMP,
                    p1_match_odds REAL,
                    p2_match_odds REAL,
                    fatality_odds REAL,
                    brutality_odds REAL,
                    no_finish_odds REAL,
                    total_rounds INTEGER DEFAULT 0,
                    fatality_round INTEGER,
                    brutality_round INTEGER,
                    no_finish_count INTEGER DEFAULT 0,
                    result TEXT DEFAULT 'pending',
                    confidence_score INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Таблица раундов
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS rounds (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    match_id TEXT NOT NULL,
                    round_num INTEGER NOT NULL,
                    winner TEXT NOT NULL,
                    finish_type TEXT NOT NULL,
                    time_seconds INTEGER,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (match_id) REFERENCES matches(match_id),
                    UNIQUE(match_id, round_num)
                )
            ''')
            
            # Таблица серий (волн)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS waves (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    start_match_id TEXT NOT NULL,
                    consecutive_no_finish INTEGER DEFAULT 0,
                    is_active BOOLEAN DEFAULT 1,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    ended_at TIMESTAMP,
                    ended_by_match_id TEXT,
                    FOREIGN KEY (start_match_id) REFERENCES matches(match_id)
                )
            ''')
            
            # Таблица ставок (улучшенная)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS bets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    match_id TEXT NOT NULL,
                    bet_type TEXT NOT NULL,
                    predicted_round INTEGER,
                    amount REAL NOT NULL,
                    odds REAL NOT NULL,
                    result TEXT DEFAULT 'pending',
                    won_in_round INTEGER,
                    profit REAL DEFAULT 0,
                    dogon_step INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP,
                    FOREIGN KEY (match_id) REFERENCES matches(match_id)
                )
            ''')
            
            # Индекс для быстрого поиска ставок
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_bets_match_id ON bets(match_id)
            ''')
            
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_bets_result ON bets(result)
            ''')
            
            # Таблица статистики по персонажам
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS character_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_name TEXT UNIQUE NOT NULL,
                    total_matches INTEGER DEFAULT 0,
                    wins INTEGER DEFAULT 0,
                    fatalities INTEGER DEFAULT 0,
                    brutalities INTEGER DEFAULT 0,
                    no_finishes INTEGER DEFAULT 0,
                    avg_rounds REAL DEFAULT 0,
                    winrate REAL DEFAULT 0,
                    fatality_rate REAL DEFAULT 0,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Таблица последних раундов для отслеживания серий
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS recent_rounds (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    match_id TEXT NOT NULL,
                    round_num INTEGER NOT NULL,
                    finish_type TEXT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Таблица для ML данных
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ml_training_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    match_id TEXT NOT NULL,
                    features TEXT NOT NULL,
                    result INTEGER NOT NULL,
                    confidence REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Таблица статистики по времени
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS time_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hour INTEGER NOT NULL,
                    minute INTEGER NOT NULL,
                    total_matches INTEGER DEFAULT 0,
                    fatalities INTEGER DEFAULT 0,
                    brutalities INTEGER DEFAULT 0,
                    no_finishes INTEGER DEFAULT 0,
                    winrate REAL DEFAULT 0,
                    UNIQUE(hour, minute)
                )
            ''')
            
            conn.commit()
            logger.info("База данных инициализирована")
    
    # === МЕТОДЫ ДЛЯ МАТЧЕЙ ===
    
    def add_match(self, match_data) -> bool:
        """Добавляет новый матч в БД"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO matches 
                    (match_id, player1, player2, league, match_time, 
                     p1_match_odds, p2_match_odds, fatality_odds, 
                     brutality_odds, no_finish_odds, confidence_score)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    match_data.match_id,
                    match_data.player1,
                    match_data.player2,
                    match_data.league,
                    match_data.timestamp,
                    match_data.p1_match_odds,
                    match_data.p2_match_odds,
                    match_data.fatality_odds,
                    match_data.brutality_odds,
                    match_data.no_finish_odds,
                    getattr(match_data, 'confidence_score', 0)
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Ошибка добавления матча: {e}")
            return False
    
    def update_match_result(self, match_id: str, result: str, 
                           total_rounds: int = 0,
                           fatality_round: Optional[int] = None,
                           brutality_round: Optional[int] = None,
                           no_finish_count: int = 0):
        """Обновляет результат матча"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE matches 
                    SET result = ?, total_rounds = ?, 
                        fatality_round = ?, brutality_round = ?, no_finish_count = ?
                    WHERE match_id = ?
                ''', (result, total_rounds, fatality_round, brutality_round, 
                      no_finish_count, match_id))
                conn.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления результата матча: {e}")
    
    def get_match(self, match_id: str) -> Optional[Dict]:
        """Получает информацию о матче"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM matches WHERE match_id = ?', (match_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Ошибка получения матча: {e}")
            return None
    
    # === МЕТОДЫ ДЛЯ РАУНДОВ ===
    
    def add_round(self, match_id: str, round_num: int, winner: str, 
                  finish_type: str, time_seconds: int = 0):
        """Добавляет раунд в БД"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO rounds 
                    (match_id, round_num, winner, finish_type, time_seconds)
                    VALUES (?, ?, ?, ?, ?)
                ''', (match_id, round_num, winner, finish_type, time_seconds))
                
                cursor.execute('''
                    INSERT INTO recent_rounds (match_id, round_num, finish_type)
                    VALUES (?, ?, ?)
                ''', (match_id, round_num, finish_type))
                
                # Очищаем старые записи (оставляем только последние 100)
                cursor.execute('''
                    DELETE FROM recent_rounds 
                    WHERE id NOT IN (
                        SELECT id FROM recent_rounds 
                        ORDER BY timestamp DESC LIMIT 100
                    )
                ''')
                
                conn.commit()
        except Exception as e:
            logger.error(f"Ошибка добавления раунда: {e}")
    
    # === МЕТОДЫ ДЛЯ СЕРИЙ (ВОЛН) ===
    
    def get_recent_no_finish_streak(self, limit: int = 10) -> int:
        """Подсчитывает текущую серию раундов без добиваний (R)"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT finish_type FROM recent_rounds
                    ORDER BY timestamp DESC
                    LIMIT ?
                ''', (limit,))
                
                rounds = cursor.fetchall()
                streak = 0
                
                for row in rounds:
                    if row['finish_type'] == 'R':
                        streak += 1
                    else:
                        break
                
                return streak
        except Exception as e:
            logger.error(f"Ошибка подсчета серии: {e}")
            return 0
    
    def get_recent_matches_no_finish_streak(self, limit: int = 5) -> int:
        """Подсчитывает серию матчей подряд без добиваний"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT match_id, finish_type FROM recent_rounds
                    WHERE match_id IN (
                        SELECT DISTINCT match_id FROM recent_rounds
                        ORDER BY timestamp DESC
                        LIMIT ?
                    )
                    ORDER BY timestamp DESC
                ''', (limit,))
                
                rows = cursor.fetchall()
                matches = {}
                for row in rows:
                    mid = row['match_id']
                    if mid not in matches:
                        matches[mid] = []
                    matches[mid].append(row['finish_type'])
                
                streak = 0
                for match_id, finishes in matches.items():
                    if 'F' not in finishes and 'B' not in finishes:
                        streak += 1
                    else:
                        break
                
                return streak
        except Exception as e:
            logger.error(f"Ошибка подсчета серии матчей: {e}")
            return 0
    
    def is_shaving_wave(self, threshold: int = 3) -> Tuple[bool, int]:
        """Проверяет, идет ли 'волна бритья'"""
        streak = self.get_recent_matches_no_finish_streak()
        return (streak >= threshold, streak)
    
    # === УЛУЧШЕННЫЕ МЕТОДЫ ДЛЯ СТАВОК ===
    
    def add_bet(self, match_id: str, bet_type: str, predicted_round: Optional[int],
                amount: float, odds: float, dogon_step: int = 0) -> Optional[int]:
        """Добавляет ставку и возвращает её ID"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO bets (match_id, bet_type, predicted_round, amount, odds, dogon_step)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (match_id, bet_type, predicted_round, amount, odds, dogon_step))
                conn.commit()
                return cursor.lastrowid
        except Exception as e:
            logger.error(f"Ошибка добавления ставки: {e}")
            return None
    
    def update_bet_result(self, bet_id: int, result: str, 
                          won_in_round: Optional[int] = None,
                          profit: float = 0):
        """Обновляет результат ставки"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE bets 
                    SET result = ?, won_in_round = ?, profit = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (result, won_in_round, profit, bet_id))
                conn.commit()
                logger.info(f"Ставка {bet_id} обновлена: result={result}, profit={profit}")
        except Exception as e:
            logger.error(f"Ошибка обновления ставки: {e}")
    
    def get_bet_by_match_id(self, match_id: str) -> Optional[Dict]:
        """Получает ставку по ID матча"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM bets WHERE match_id = ? ORDER BY id DESC LIMIT 1
                ''', (match_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Ошибка получения ставки: {e}")
            return None
    
    def get_pending_bets(self) -> List[Dict]:
        """Получает ожидающие ставки"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM bets WHERE result = \'pending\'')
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения ставок: {e}")
            return []
    
    def get_recent_losses(self, limit: int = 3) -> List[Dict]:
        """Получает последние проигрыши для догона"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM bets 
                    WHERE result = 'lost' 
                    ORDER BY updated_at DESC 
                    LIMIT ?
                ''', (limit,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения проигрышей: {e}")
            return []
    
    def get_bet_stats(self, days: int = 1) -> Dict:
        """Получает статистику ставок за период"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN result = 'won' THEN 1 ELSE 0 END) as wins,
                        SUM(CASE WHEN result = 'lost' THEN 1 ELSE 0 END) as losses,
                        SUM(CASE WHEN result = 'pending' THEN 1 ELSE 0 END) as pending,
                        SUM(CASE WHEN result = 'won' THEN profit ELSE 0 END) as total_profit,
                        SUM(CASE WHEN result = 'lost' THEN -amount ELSE 0 END) as total_loss
                    FROM bets
                    WHERE created_at >= datetime('now', ?)
                ''', (f'-{days} days',))
                
                row = cursor.fetchone()
                if row:
                    return {
                        'total': row['total'] or 0,
                        'wins': row['wins'] or 0,
                        'losses': row['losses'] or 0,
                        'pending': row['pending'] or 0,
                        'total_profit': row['total_profit'] or 0,
                        'total_loss': row['total_loss'] or 0,
                        'net_profit': (row['total_profit'] or 0) + (row['total_loss'] or 0),
                        'winrate': (row['wins'] / (row['wins'] + row['losses']) * 100) 
                                   if (row['wins'] + row['losses']) > 0 else 0
                    }
                return {'total': 0, 'wins': 0, 'losses': 0, 'pending': 0, 
                        'total_profit': 0, 'total_loss': 0, 'net_profit': 0, 'winrate': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {'total': 0, 'wins': 0, 'losses': 0, 'pending': 0,
                    'total_profit': 0, 'total_loss': 0, 'net_profit': 0, 'winrate': 0}
    
    # === МЕТОДЫ ДЛЯ СТАТИСТИКИ ===
    
    def update_character_stats(self, character_name: str, won: bool = False,
                               fatality: bool = False, brutality: bool = False,
                               no_finish: bool = False, rounds: int = 0):
        """Обновляет статистику персонажа"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO character_stats (character_name, total_matches, wins, 
                        fatalities, brutalities, no_finishes, avg_rounds, winrate, fatality_rate)
                    VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(character_name) DO UPDATE SET
                        total_matches = total_matches + 1,
                        wins = wins + ?,
                        fatalities = fatalities + ?,
                        brutalities = brutalities + ?,
                        no_finishes = no_finishes + ?,
                        avg_rounds = (avg_rounds * total_matches + ?) / (total_matches + 1),
                        winrate = (wins * 100.0) / (total_matches + 1),
                        fatality_rate = (fatalities * 100.0) / (total_matches + 1),
                        updated_at = CURRENT_TIMESTAMP
                ''', (character_name, int(won), int(fatality), int(brutality), 
                      int(no_finish), rounds, int(won) * 100, int(fatality) * 100,
                      int(won), int(fatality), int(brutality), int(no_finish), rounds))
                conn.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления статистики персонажа: {e}")
    
    def get_time_pattern_stats(self, hour: int, minute: int) -> Dict:
        """Получает статистику для конкретного времени"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                time_pattern = f"{hour:02d}:{minute:02d}"
                
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN fatality_round IS NOT NULL THEN 1 ELSE 0 END) as fatalities,
                        SUM(CASE WHEN brutality_round IS NOT NULL THEN 1 ELSE 0 END) as brutalities
                    FROM matches
                    WHERE strftime('%H:%M', match_time) = ?
                    AND result != 'pending'
                ''', (time_pattern,))
                
                row = cursor.fetchone()
                if row and row['total'] > 0:
                    total = row['total']
                    return {
                        'total_matches': total,
                        'fatality_rate': row['fatalities'] / total * 100,
                        'brutality_rate': row['brutalities'] / total * 100,
                        'any_finish_rate': (row['fatalities'] + row['brutalities']) / total * 100
                    }
                return {'total_matches': 0, 'fatality_rate': 0, 'brutality_rate': 0, 'any_finish_rate': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики по времени: {e}")
            return {'total_matches': 0, 'fatality_rate': 0, 'brutality_rate': 0, 'any_finish_rate': 0}
    
    def get_combo_stats(self, executor: str, donor: str) -> Dict:
        """Получает статистику комбинации Палач-Донор"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN fatality_round IS NOT NULL THEN 1 ELSE 0 END) as fatalities,
                        AVG(fatality_round) as avg_fatality_round
                    FROM matches
                    WHERE ((player1 = ? AND player2 = ?) OR (player1 = ? AND player2 = ?))
                    AND result != 'pending'
                ''', (executor, donor, donor, executor))
                
                row = cursor.fetchone()
                if row and row['total'] > 0:
                    total = row['total']
                    return {
                        'total_matches': total,
                        'fatality_rate': row['fatalities'] / total * 100,
                        'avg_fatality_round': row['avg_fatality_round'] or 0
                    }
                return {'total_matches': 0, 'fatality_rate': 0, 'avg_fatality_round': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики комбо: {e}")
            return {'total_matches': 0, 'fatality_rate': 0, 'avg_fatality_round': 0}
    
    # === ML МЕТОДЫ ===
    
    def add_ml_training_data(self, match_id: str, features: Dict, result: int, confidence: float):
        """Добавляет данные для обучения ML"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO ml_training_data (match_id, features, result, confidence)
                    VALUES (?, ?, ?, ?)
                ''', (match_id, json.dumps(features), result, confidence))
                conn.commit()
        except Exception as e:
            logger.error(f"Ошибка добавления ML данных: {e}")
    
    def get_ml_training_data(self, limit: int = 1000) -> List[Dict]:
        """Получает данные для обучения ML"""
        try:
            with self.pool.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM ml_training_data
                    ORDER BY created_at DESC
                    LIMIT ?
                ''', (limit,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения ML данных: {e}")
            return []


# Глобальный экземпляр БД
db = MKXDatabase()
