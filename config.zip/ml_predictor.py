"""
ML Predictor для MKX Strategy Bot v3.0
Адаптивная модель для предсказания вероятности успеха ставки
"""

import json
import logging
import pickle
import os
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import numpy as np

logger = logging.getLogger(__name__)

# Пробуем импортировать sklearn, если доступен
try:
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn не установлен. ML функции будут ограничены.")

import config
from database import db
from characters_db import get_character_type, EXECUTORS, DONORS


@dataclass
class MatchFeatures:
    """Признаки матча для ML"""
    executor_strength: float  # 0-100
    donor_weakness: float  # 0-100
    time_pattern_score: float  # 0-100
    recent_wave_factor: float  # 0-100
    odds_value: float  # 0-100
    confidence_score: float  # 0-100
    p1_odds: float
    p2_odds: float
    fatality_odds: float
    is_golden_minute: bool
    is_dead_minute: bool
    wave_streak: int
    consecutive_losses: int


class SimpleMLModel:
    """Простая ML модель на основе взвешенной суммы признаков"""
    
    def __init__(self):
        # Веса признаков (настраиваются на основе исторических данных)
        self.weights = {
            'executor_strength': 0.20,
            'donor_weakness': 0.15,
            'time_pattern_score': 0.15,
            'recent_wave_factor': 0.15,
            'odds_value': 0.10,
            'confidence_score': 0.15,
            'wave_streak': 0.10
        }
        
        # Пороги для классификации
        self.threshold_high = 70
        self.threshold_medium = 50
        
        # Статистика модели
        self.total_predictions = 0
        self.correct_predictions = 0
    
    def predict(self, features: MatchFeatures) -> Tuple[float, str]:
        """
        Предсказывает вероятность успеха
        
        Returns:
            (probability: float 0-100, recommendation: str)
        """
        # Нормализуем признаки
        executor_score = min(features.executor_strength / 100, 1.0)
        donor_score = min(features.donor_weakness / 100, 1.0)
        time_score = min(features.time_pattern_score / 100, 1.0)
        wave_score = min(features.recent_wave_factor / 100, 1.0)
        odds_score = min(features.odds_value / 100, 1.0)
        confidence_score = min(features.confidence_score / 100, 1.0)
        
        # Учет волны бритья
        wave_bonus = min(features.wave_streak * 5, 25) / 100
        
        # Штраф за подряд проигрыши
        loss_penalty = min(features.consecutive_losses * 5, 20) / 100
        
        # Расчет взвешенной суммы
        probability = (
            executor_score * self.weights['executor_strength'] +
            donor_score * self.weights['donor_weakness'] +
            time_score * self.weights['time_pattern_score'] +
            wave_score * self.weights['recent_wave_factor'] +
            odds_score * self.weights['odds_value'] +
            confidence_score * self.weights['confidence_score'] +
            wave_bonus -
            loss_penalty
        ) * 100
        
        # Ограничиваем диапазон
        probability = max(0, min(100, probability))
        
        # Определяем рекомендацию
        if probability >= self.threshold_high:
            recommendation = "STRONG"
        elif probability >= self.threshold_medium:
            recommendation = "MEDIUM"
        else:
            recommendation = "WEAK"
        
        self.total_predictions += 1
        
        return probability, recommendation
    
    def update_weights(self, feature_name: str, new_weight: float):
        """Обновляет вес признака"""
        if feature_name in self.weights:
            self.weights[feature_name] = max(0, min(1, new_weight))
            # Нормализуем веса
            total = sum(self.weights.values())
            for key in self.weights:
                self.weights[key] /= total
            logger.info(f"Обновлен вес {feature_name}: {self.weights[feature_name]:.3f}")
    
    def record_result(self, predicted_prob: float, actual_result: bool):
        """Записывает результат для анализа точности"""
        # Считаем предсказание верным если:
        # - Вероятность > 60% и результат = выигрыш
        # - Вероятность < 40% и результат = проигрыш
        predicted_win = predicted_prob > 50
        if predicted_win == actual_result:
            self.correct_predictions += 1
        
        accuracy = self.correct_predictions / self.total_predictions * 100
        logger.info(f"Точность модели: {accuracy:.1f}% ({self.correct_predictions}/{self.total_predictions})")


class AdvancedMLModel:
    """Продвинутая ML модель на основе Gradient Boosting"""
    
    def __init__(self, model_file: str = "ml_model.pkl"):
        self.model_file = model_file
        self.model = None
        self.scaler = StandardScaler()
        self.is_trained = False
        
        if SKLEARN_AVAILABLE:
            self._load_or_create_model()
    
    def _load_or_create_model(self):
        """Загружает или создает новую модель"""
        if os.path.exists(self.model_file):
            try:
                with open(self.model_file, 'rb') as f:
                    data = pickle.load(f)
                    self.model = data['model']
                    self.scaler = data['scaler']
                    self.is_trained = True
                logger.info("ML модель загружена из файла")
            except Exception as e:
                logger.error(f"Ошибка загрузки модели: {e}")
                self._create_new_model()
        else:
            self._create_new_model()
    
    def _create_new_model(self):
        """Создает новую модель"""
        if not SKLEARN_AVAILABLE:
            return
        
        self.model = GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=3,
            random_state=42
        )
        self.is_trained = False
        logger.info("Создана новая ML модель")
    
    def _extract_features(self, features: MatchFeatures) -> np.ndarray:
        """Извлекает признаки в numpy массив"""
        return np.array([
            features.executor_strength,
            features.donor_weakness,
            features.time_pattern_score,
            features.recent_wave_factor,
            features.odds_value,
            features.confidence_score,
            features.p1_odds,
            features.p2_odds,
            features.fatality_odds,
            1 if features.is_golden_minute else 0,
            1 if features.is_dead_minute else 0,
            features.wave_streak,
            features.consecutive_losses
        ]).reshape(1, -1)
    
    def train(self, training_data: List[Dict]):
        """Обучает модель на исторических данных"""
        if not SKLEARN_AVAILABLE or len(training_data) < config.ML_MIN_SAMPLES:
            logger.warning(f"Недостаточно данных для обучения. Нужно: {config.ML_MIN_SAMPLES}")
            return
        
        try:
            # Подготовка данных
            X = []
            y = []
            
            for record in training_data:
                features = json.loads(record['features'])
                X.append([
                    features.get('executor_strength', 0),
                    features.get('donor_weakness', 0),
                    features.get('time_pattern_score', 0),
                    features.get('recent_wave_factor', 0),
                    features.get('odds_value', 0),
                    features.get('confidence_score', 0),
                    features.get('p1_odds', 0),
                    features.get('p2_odds', 0),
                    features.get('fatality_odds', 0),
                    features.get('is_golden_minute', 0),
                    features.get('is_dead_minute', 0),
                    features.get('wave_streak', 0),
                    features.get('consecutive_losses', 0)
                ])
                y.append(record['result'])
            
            X = np.array(X)
            y = np.array(y)
            
            # Разделение на train/test
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Нормализация
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Обучение
            self.model.fit(X_train_scaled, y_train)
            
            # Оценка
            train_score = self.model.score(X_train_scaled, y_train)
            test_score = self.model.score(X_test_scaled, y_test)
            
            self.is_trained = True
            
            logger.info(f"Модель обучена. Train accuracy: {train_score:.3f}, Test accuracy: {test_score:.3f}")
            
            # Сохранение
            self._save_model()
            
        except Exception as e:
            logger.error(f"Ошибка обучения модели: {e}")
    
    def predict(self, features: MatchFeatures) -> Tuple[float, str]:
        """Предсказывает вероятность успеха"""
        if not self.is_trained or not SKLEARN_AVAILABLE:
            return 50.0, "UNKNOWN"
        
        try:
            X = self._extract_features(features)
            X_scaled = self.scaler.transform(X)
            
            # Предсказание вероятности
            prob = self.model.predict_proba(X_scaled)[0]
            probability = prob[1] * 100  # Вероятность класса 1 (успех)
            
            # Рекомендация
            if probability >= 70:
                recommendation = "STRONG"
            elif probability >= 50:
                recommendation = "MEDIUM"
            else:
                recommendation = "WEAK"
            
            return probability, recommendation
            
        except Exception as e:
            logger.error(f"Ошибка предсказания: {e}")
            return 50.0, "UNKNOWN"
    
    def _save_model(self):
        """Сохраняет модель в файл"""
        try:
            with open(self.model_file, 'wb') as f:
                pickle.dump({
                    'model': self.model,
                    'scaler': self.scaler
                }, f)
            logger.info("ML модель сохранена")
        except Exception as e:
            logger.error(f"Ошибка сохранения модели: {e}")


class MLPredictor:
    """Основной класс для ML предсказаний"""
    
    def __init__(self):
        self.simple_model = SimpleMLModel()
        self.advanced_model = AdvancedMLModel()
        self.use_advanced = SKLEARN_AVAILABLE
    
    def extract_features(self, match_data, analyzer_data: Dict) -> MatchFeatures:
        """Извлекает признаки из данных матча"""
        # Определяем типы персонажей
        p1_type, p1_info = get_character_type(match_data.player1)
        p2_type, p2_info = get_character_type(match_data.player2)
        
        # Сила палача
        executor_strength = 0
        if p1_type == "EXECUTOR":
            executor_strength = p1_info.get('winrate', 50)
        
        # Слабость донора
        donor_weakness = 0
        if p2_type == "DONOR":
            donor_weakness = p2_info.get('donor_rate', 50)
        
        # Временной паттерн
        from main import is_golden_minute_range
        match_time = match_data.timestamp.strftime("%H:%M")
        is_golden, _ = is_golden_minute_range(match_time)
        time_stats = db.get_time_pattern_stats(match_data.timestamp.hour, match_data.timestamp.minute)
        time_pattern_score = time_stats.get('any_finish_rate', 50)
        
        # Фактор волны
        is_wave, wave_streak = db.is_shaving_wave(threshold=3)
        recent_wave_factor = min(wave_streak * 10, 50) if is_wave else 0
        
        # Ценность коэффициента
        ideal_min, ideal_max = config.IDEAL_FATality_KF_RANGE
        odds_value = 0
        if ideal_min <= match_data.fatality_odds <= ideal_max:
            odds_value = 100
        elif match_data.fatality_odds >= config.MIN_FATality_KF:
            odds_value = 70
        
        # Признаки
        return MatchFeatures(
            executor_strength=executor_strength,
            donor_weakness=donor_weakness,
            time_pattern_score=time_pattern_score,
            recent_wave_factor=recent_wave_factor,
            odds_value=odds_value,
            confidence_score=analyzer_data.get('confidence_score', 0),
            p1_odds=match_data.p1_match_odds,
            p2_odds=match_data.p2_match_odds,
            fatality_odds=match_data.fatality_odds,
            is_golden_minute=is_golden,
            is_dead_minute=match_time in config.DEAD_MINUTES,
            wave_streak=wave_streak,
            consecutive_losses=analyzer_data.get('consecutive_losses', 0)
        )
    
    def predict(self, match_data, analyzer_data: Dict) -> Tuple[float, str, Dict]:
        """
        Делает предсказание для матча
        
        Returns:
            (probability, recommendation, details)
        """
        features = self.extract_features(match_data, analyzer_data)
        
        # Используем продвинутую модель если доступна
        if self.use_advanced and self.advanced_model.is_trained:
            probability, recommendation = self.advanced_model.predict(features)
            model_used = "advanced"
        else:
            probability, recommendation = self.simple_model.predict(features)
            model_used = "simple"
        
        details = {
            'model_used': model_used,
            'features': {
                'executor_strength': features.executor_strength,
                'donor_weakness': features.donor_weakness,
                'time_pattern_score': features.time_pattern_score,
                'recent_wave_factor': features.recent_wave_factor,
                'odds_value': features.odds_value,
                'wave_streak': features.wave_streak
            }
        }
        
        return probability, recommendation, details
    
    def record_result(self, match_id: str, features: Dict, result: bool):
        """Записывает результат для обучения"""
        # Сохраняем в БД для будущего обучения
        db.add_ml_training_data(match_id, features, 1 if result else 0, 0)
        
        # Обновляем статистику простой модели
        # (в реальности здесь нужно хранить предсказание до матча)
    
    def train_if_needed(self):
        """Обучает модель если накоплено достаточно данных"""
        if not self.use_advanced:
            return
        
        training_data = db.get_ml_training_data(limit=1000)
        
        if len(training_data) >= config.ML_MIN_SAMPLES:
            logger.info(f"Обучение модели на {len(training_data)} записях...")
            self.advanced_model.train(training_data)
        else:
            logger.info(f"Недостаточно данных для обучения. Накоплено: {len(training_data)}/{config.ML_MIN_SAMPLES}")


# Глобальный экземпляр предиктора
ml_predictor = MLPredictor()
