"""
Менеджер банкролла для MKX Strategy Bot v3.0
Управляет балансом, лимитами потерь и прогрессией ставок (догон)
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from dataclasses import dataclass, asdict
import config

logger = logging.getLogger(__name__)


@dataclass
class DailyStats:
    """Статистика за день"""
    date: str
    total_bets: int = 0
    wins: int = 0
    losses: int = 0
    profit: float = 0
    max_drawdown: float = 0


@dataclass
class BankrollState:
    """Состояние банкролла"""
    current_balance: float
    initial_balance: float
    daily_loss: float
    daily_profit: float
    last_reset_date: str
    total_bets_placed: int = 0
    total_wins: int = 0
    total_losses: int = 0
    current_dogon_step: int = 0  # Текущий шаг догона (0 = нет догона)
    consecutive_losses: int = 0
    max_balance_achieved: float = 0


class BankrollManager:
    """Менеджер управления банкроллом и догоном"""
    
    def __init__(self, state_file: str = config.BANKROLL_FILE):
        self.state_file = state_file
        self.daily_limit = config.INITIAL_BANKROLL * (config.MAX_DAILY_LOSS_PERCENT / 100)
        self.max_bet_percent = config.MAX_BET_PERCENT
        self.progression = config.BET_PROGRESSION
        self.state = self._load_state()
        self._check_daily_reset()
    
    def _load_state(self) -> BankrollState:
        """Загружает состояние банкролла из файла"""
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return BankrollState(**data)
        except (FileNotFoundError, json.JSONDecodeError):
            logger.info("Создание нового состояния банкролла")
            return BankrollState(
                current_balance=config.INITIAL_BANKROLL,
                initial_balance=config.INITIAL_BANKROLL,
                daily_loss=0,
                daily_profit=0,
                last_reset_date=datetime.now().strftime('%Y-%m-%d'),
                max_balance_achieved=config.INITIAL_BANKROLL
            )
    
    def _save_state(self):
        """Сохраняет состояние банкролла"""
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(asdict(self.state), f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения состояния банкролла: {e}")
    
    def _check_daily_reset(self):
        """Проверяет и выполняет ежедневный сброс лимитов"""
        today = datetime.now().strftime('%Y-%m-%d')
        if self.state.last_reset_date != today:
            logger.info(f"Ежедневный сброс лимитов. Вчерашняя прибыль: {self.state.daily_profit:.2f}")
            self.state.daily_loss = 0
            self.state.daily_profit = 0
            self.state.last_reset_date = today
            self.state.consecutive_losses = 0
            self.state.current_dogon_step = 0
            self._save_state()
    
    def can_place_bet(self, amount: Optional[float] = None) -> tuple:
        """
        Проверяет, можно ли сделать ставку
        
        Returns:
            (can_bet: bool, reason: str, recommended_amount: float)
        """
        self._check_daily_reset()
        
        # Проверка дневного лимита потерь
        if self.state.daily_loss >= self.daily_limit:
            return False, f"Дневной лимит потерь достигнут: {self.state.daily_loss:.2f} руб.", 0
        
        # Проверка на банкротство
        if self.state.current_balance <= 0:
            return False, "Баланс исчерпан!", 0
        
        # Определяем сумму ставки
        if amount is None:
            amount = self.get_next_bet_amount()
        
        # Проверка максимального размера ставки
        max_bet = self.state.current_balance * (self.max_bet_percent / 100)
        if amount > max_bet:
            logger.warning(f"Ставка {amount} превышает максимум {max_bet:.2f}. Корректировка.")
            amount = max_bet
        
        # Проверка, хватает ли баланса
        if amount > self.state.current_balance:
            return False, f"Недостаточно средств. Баланс: {self.state.current_balance:.2f}", 0
        
        # Проверка на слишком большой догон
        if self.state.current_dogon_step >= len(self.progression):
            return False, "Достигнут максимальный шаг догона. Сброс.", 0
        
        return True, "OK", amount
    
    def get_next_bet_amount(self) -> float:
        """Определяет сумму следующей ставки на основе прогрессии"""
        step = min(self.state.current_dogon_step, len(self.progression) - 1)
        return float(self.progression[step])
    
    def place_bet(self, amount: Optional[float] = None) -> float:
        """
        Регистрирует размещение ставки
        
        Returns:
            Сумма ставки
        """
        can_bet, reason, recommended_amount = self.can_place_bet(amount)
        
        if not can_bet:
            logger.warning(f"Невозможно сделать ставку: {reason}")
            return 0
        
        amount = recommended_amount
        self.state.current_balance -= amount
        self.state.total_bets_placed += 1
        
        logger.info(f"Ставка размещена: {amount:.2f} руб. (шаг догона: {self.state.current_dogon_step})")
        self._save_state()
        
        return amount
    
    def record_win(self, amount: float, odds: float, round_num: int):
        """Регистрирует выигрыш"""
        # Расчет прибыли: ставка * коэффициент
        profit = amount * odds
        net_profit = profit - amount  # Чистая прибыль
        
        self.state.current_balance += profit
        self.state.daily_profit += net_profit
        self.state.total_wins += 1
        self.state.consecutive_losses = 0
        self.state.current_dogon_step = 0  # Сброс догона при выигрыше
        
        # Обновляем максимальный баланс
        if self.state.current_balance > self.state.max_balance_achieved:
            self.state.max_balance_achieved = self.state.current_balance
        
        logger.info(f"Выигрыш! Прибыль: +{net_profit:.2f} руб. Новый баланс: {self.state.current_balance:.2f}")
        self._save_state()
        
        return net_profit
    
    def record_loss(self, amount: float):
        """Регистрирует проигрыш"""
        self.state.daily_loss += amount
        self.state.total_losses += 1
        self.state.consecutive_losses += 1
        
        # Увеличиваем шаг догона
        self.state.current_dogon_step += 1
        
        # Если достигли максимального шага - сбрасываем
        if self.state.current_dogon_step >= len(self.progression):
            logger.warning("Достигнут максимальный шаг догона. Сброс прогрессии.")
            self.state.current_dogon_step = 0
            self.state.consecutive_losses = 0
        
        logger.info(f"Проигрыш. Убыток: -{amount:.2f} руб. Следующий шаг догона: {self.state.current_dogon_step}")
        self._save_state()
        
        return -amount
    
    def get_current_drawdown(self) -> float:
        """Возвращает текущую просадку от максимума"""
        if self.state.max_balance_achieved <= 0:
            return 0
        drawdown = (self.state.max_balance_achieved - self.state.current_balance) / self.state.max_balance_achieved * 100
        return drawdown
    
    def get_stats(self) -> Dict:
        """Возвращает полную статистику"""
        self._check_daily_reset()
        
        total_profit = self.state.current_balance - self.state.initial_balance
        roi = (total_profit / self.state.initial_balance * 100) if self.state.initial_balance > 0 else 0
        winrate = (self.state.total_wins / (self.state.total_wins + self.state.total_losses) * 100) \
                  if (self.state.total_wins + self.state.total_losses) > 0 else 0
        
        return {
            'current_balance': self.state.current_balance,
            'initial_balance': self.state.initial_balance,
            'total_profit': total_profit,
            'roi_percent': roi,
            'daily_profit': self.state.daily_profit,
            'daily_loss': self.state.daily_loss,
            'daily_limit': self.daily_limit,
            'daily_remaining': self.daily_limit - self.state.daily_loss,
            'total_bets': self.state.total_bets_placed,
            'wins': self.state.total_wins,
            'losses': self.state.total_losses,
            'winrate': winrate,
            'consecutive_losses': self.state.consecutive_losses,
            'current_dogon_step': self.state.current_dogon_step,
            'next_bet_amount': self.get_next_bet_amount(),
            'max_balance': self.state.max_balance_achieved,
            'current_drawdown': self.get_current_drawdown(),
            'can_bet': self.can_place_bet()[0]
        }
    
    def reset_dogon(self):
        """Сбрасывает прогрессию догона"""
        self.state.current_dogon_step = 0
        self.state.consecutive_losses = 0
        self._save_state()
        logger.info("Прогрессия догона сброшена")
    
    def emergency_stop(self) -> bool:
        """Проверяет, нужна ли экстренная остановка"""
        # Остановка при просадке более 50%
        if self.get_current_drawdown() > 50:
            return True
        
        # Остановка при 5 подряд проигрышах
        if self.state.consecutive_losses >= 5:
            return True
        
        # Остановка если баланс упал ниже 20% от начального
        if self.state.current_balance < self.state.initial_balance * 0.2:
            return True
        
        return False
    
    def format_status_message(self) -> str:
        """Форматирует сообщение со статусом банкролла"""
        stats = self.get_stats()
        
        status_emoji = "🟢" if stats['can_bet'] else "🔴"
        emergency = "🚨 ЭКСТРЕННАЯ ОСТАНОВКА!" if self.emergency_stop() else ""
        
        return f"""
{status_emoji} <b>БАНКРОЛЛ</b>

💰 Текущий баланс: <b>{stats['current_balance']:.2f}</b> руб.
📊 Начальный баланс: {stats['initial_balance']:.2f} руб.
💵 Общая прибыль: {stats['total_profit']:+.2f} руб. ({stats['roi_percent']:+.1f}%)

📈 Статистика:
• Ставок: {stats['total_bets']} | ✅ {stats['wins']} | ❌ {stats['losses']}
• Винрейт: {stats['winrate']:.1f}%
• Просадка: {stats['current_drawdown']:.1f}%

📅 Сегодня:
• Прибыль: {stats['daily_profit']:+.2f} руб.
• Убыток: {stats['daily_loss']:.2f} / {stats['daily_limit']:.2f} руб.

🎯 Догон: шаг {stats['current_dogon_step']}
💵 Следующая ставка: {stats['next_bet_amount']:.2f} руб.

{emergency}
"""


# Глобальный экземпляр менеджера банкролла
bankroll = BankrollManager()
