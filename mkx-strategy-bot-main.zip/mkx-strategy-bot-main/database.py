"""
SQLite база данных для отслеживания статистики и серий MKX
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

DB_FILE = "mkx_stats.db"


@dataclass
class RoundHistory:
    """История раундов для отслеживания серий"""
    match_id: str
    round_num: int
    winner: str
    finish_type: str  # F, B, R
    timestamp: datetime


@dataclass
class MatchResult:
    """Результат матча"""
    match_id: str
    player1: str
    player2: str
    total_rounds: int
    fatality_round: Optional[int]  # в каком раунде было добивание
    brutality_round: Optional[int]
    no_finish_count: int
    result: str  # 'won', 'lost', 'pending'
    timestamp: datetime


class MKXDatabase:
    """База данных для хранения статистики MKX"""
    
    def __init__(self, db_file: str = DB_FILE):
        self.db_file = db_file
        self.init_database()
    
    def get_connection(self):
        """Получает соединение с БД"""
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Инициализирует таблицы БД"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Таблица матчей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT UNIQUE NOT NULL,
                player1 TEXT NOT NULL,
                player2 TEXT NOT NULL,
                league TEXT,
                match_time TIMESTAMP,
                p1_match_odds REAL,
                p2_match_odds REAL,
                fatality_odds REAL,
                brutality_odds REAL,
                no_finish_odds REAL,
                total_rounds INTEGER DEFAULT 0,
                fatality_round INTEGER,
                brutality_round INTEGER,
                no_finish_count INTEGER DEFAULT 0,
                result TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица раундов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rounds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                round_num INTEGER NOT NULL,
                winner TEXT NOT NULL,
                finish_type TEXT NOT NULL,
                time_seconds INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (match_id) REFERENCES matches(match_id),
                UNIQUE(match_id, round_num)
            )
        ''')
        
        # Таблица серий (волн)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS waves (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                start_match_id TEXT NOT NULL,
                consecutive_no_finish INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ended_at TIMESTAMP,
                ended_by_match_id TEXT,
                FOREIGN KEY (start_match_id) REFERENCES matches(match_id)
            )
        ''')
        
        # Таблица ставок
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                bet_type TEXT NOT NULL,  -- 'fatality', 'brutality', 'round_win'
                predicted_round INTEGER,
                amount REAL,
                odds REAL,
                result TEXT DEFAULT 'pending',  -- 'won', 'lost', 'pending'
                won_in_round INTEGER,
                profit REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (match_id) REFERENCES matches(match_id)
            )
        ''')
        
        # Таблица статистики по персонажам
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS character_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                character_name TEXT UNIQUE NOT NULL,
                total_matches INTEGER DEFAULT 0,
                wins INTEGER DEFAULT 0,
                fatalities INTEGER DEFAULT 0,
                brutalities INTEGER DEFAULT 0,
                no_finishes INTEGER DEFAULT 0,
                avg_rounds REAL DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица последних раундов для отслеживания серий
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS recent_rounds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                round_num INTEGER NOT NULL,
                finish_type TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
        logger.info("База данных инициализирована")
    
    # === МЕТОДЫ ДЛЯ МАТЧЕЙ ===
    
    def add_match(self, match_data) -> bool:
        """Добавляет новый матч в БД"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO matches 
                (match_id, player1, player2, league, match_time, 
                 p1_match_odds, p2_match_odds, fatality_odds, 
                 brutality_odds, no_finish_odds)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                match_data.match_id,
                match_data.player1,
                match_data.player2,
                match_data.league,
                match_data.timestamp,
                match_data.p1_match_odds,
                match_data.p2_match_odds,
                match_data.fatality_odds,
                match_data.brutality_odds,
                match_data.no_finish_odds
            ))
            conn.commit()
            return True
        except Exception as e:
            logger.error(f"Ошибка добавления матча: {e}")
            return False
        finally:
            conn.close()
    
    def update_match_result(self, match_id: str, result: str, 
                           total_rounds: int = 0,
                           fatality_round: Optional[int] = None,
                           brutality_round: Optional[int] = None,
                           no_finish_count: int = 0):
        """Обновляет результат матча"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE matches 
                SET result = ?, total_rounds = ?, 
                    fatality_round = ?, brutality_round = ?, no_finish_count = ?
                WHERE match_id = ?
            ''', (result, total_rounds, fatality_round, brutality_round, 
                  no_finish_count, match_id))
            conn.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления результата: {e}")
        finally:
            conn.close()
    
    def get_match(self, match_id: str) -> Optional[Dict]:
        """Получает информацию о матче"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT * FROM matches WHERE match_id = ?', (match_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Ошибка получения матча: {e}")
            return None
        finally:
            conn.close()
    
    # === МЕТОДЫ ДЛЯ РАУНДОВ ===
    
    def add_round(self, match_id: str, round_num: int, winner: str, 
                  finish_type: str, time_seconds: int = 0):
        """Добавляет раунд в БД"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO rounds 
                (match_id, round_num, winner, finish_type, time_seconds)
                VALUES (?, ?, ?, ?, ?)
            ''', (match_id, round_num, winner, finish_type, time_seconds))
            
            # Также добавляем в recent_rounds для отслеживания серий
            cursor.execute('''
                INSERT INTO recent_rounds (match_id, round_num, finish_type)
                VALUES (?, ?, ?)
            ''', (match_id, round_num, finish_type))
            
            # Очищаем старые записи (оставляем только последние 50)
            cursor.execute('''
                DELETE FROM recent_rounds 
                WHERE id NOT IN (
                    SELECT id FROM recent_rounds 
                    ORDER BY timestamp DESC LIMIT 50
                )
            ''')
            
            conn.commit()
        except Exception as e:
            logger.error(f"Ошибка добавления раунда: {e}")
        finally:
            conn.close()
    
    def get_match_rounds(self, match_id: str) -> List[Dict]:
        """Получает все раунды матча"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT * FROM rounds 
                WHERE match_id = ? 
                ORDER BY round_num
            ''', (match_id,))
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения раундов: {e}")
            return []
        finally:
            conn.close()
    
    # === МЕТОДЫ ДЛЯ СЕРИЙ (ВОЛН) ===
    
    def get_recent_no_finish_streak(self, limit: int = 10) -> int:
        """
        Подсчитывает текущую серию раундов без добиваний (R)
        Возвращает количество подряд раундов без добиваний
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT finish_type FROM recent_rounds
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (limit,))
            
            rounds = cursor.fetchall()
            streak = 0
            
            for row in rounds:
                if row['finish_type'] == 'R':
                    streak += 1
                else:
                    break  # Серия прервана
            
            return streak
        except Exception as e:
            logger.error(f"Ошибка подсчета серии: {e}")
            return 0
        finally:
            conn.close()
    
    def get_recent_matches_no_finish_streak(self, limit: int = 5) -> int:
        """
        Подсчитывает серию матчей подряд без добиваний (3:0 или 3:1 с R)
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT match_id, finish_type FROM recent_rounds
                WHERE match_id IN (
                    SELECT DISTINCT match_id FROM recent_rounds
                    ORDER BY timestamp DESC
                    LIMIT ?
                )
                ORDER BY timestamp DESC
            ''', (limit,))
            
            rows = cursor.fetchall()
            
            # Группируем по матчам
            matches = {}
            for row in rows:
                mid = row['match_id']
                if mid not in matches:
                    matches[mid] = []
                matches[mid].append(row['finish_type'])
            
            # Считаем серию матчей без F/B
            streak = 0
            for match_id, finishes in matches.items():
                if 'F' not in finishes and 'B' not in finishes:
                    streak += 1
                else:
                    break
            
            return streak
        except Exception as e:
            logger.error(f"Ошибка подсчета серии матчей: {e}")
            return 0
        finally:
            conn.close()
    
    def is_shaving_wave(self, threshold: int = 3) -> Tuple[bool, int]:
        """
        Проверяет, идет ли "волна бритья" (серия без добиваний)
        
        Returns:
            (is_wave: bool, streak: int)
        """
        streak = self.get_recent_matches_no_finish_streak()
        return (streak >= threshold, streak)
    
    def get_last_fatality_info(self) -> Optional[Dict]:
        """Получает информацию о последнем матче с Fatality"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT * FROM rounds
                WHERE finish_type = 'F'
                ORDER BY timestamp DESC
                LIMIT 1
            ''')
            row = cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Ошибка получения последнего F: {e}")
            return None
        finally:
            conn.close()
    
    # === МЕТОДЫ ДЛЯ СТАТИСТИКИ ===
    
    def get_character_stats(self, character_name: str) -> Dict:
        """Получает статистику персонажа"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT * FROM character_stats 
                WHERE character_name = ?
            ''', (character_name,))
            row = cursor.fetchone()
            
            if row:
                return dict(row)
            else:
                return {
                    'character_name': character_name,
                    'total_matches': 0,
                    'wins': 0,
                    'fatalities': 0,
                    'brutalities': 0,
                    'no_finishes': 0,
                    'avg_rounds': 0
                }
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {}
        finally:
            conn.close()
    
    def update_character_stats(self, character_name: str, won: bool = False,
                               fatality: bool = False, brutality: bool = False,
                               no_finish: bool = False, rounds: int = 0):
        """Обновляет статистику персонажа"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO character_stats (character_name, total_matches, wins, 
                    fatalities, brutalities, no_finishes, avg_rounds)
                VALUES (?, 1, ?, ?, ?, ?, ?)
                ON CONFLICT(character_name) DO UPDATE SET
                    total_matches = total_matches + 1,
                    wins = wins + ?,
                    fatalities = fatalities + ?,
                    brutalities = brutalities + ?,
                    no_finishes = no_finishes + ?,
                    avg_rounds = (avg_rounds * total_matches + ?) / (total_matches + 1),
                    updated_at = CURRENT_TIMESTAMP
            ''', (character_name, int(won), int(fatality), int(brutality), 
                  int(no_finish), rounds, int(won), int(fatality), 
                  int(brutality), int(no_finish), rounds))
            conn.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления статистики: {e}")
        finally:
            conn.close()
    
    # === МЕТОДЫ ДЛЯ СТАВОК ===
    
    def add_bet(self, match_id: str, bet_type: str, predicted_round: Optional[int],
                amount: float, odds: float):
        """Добавляет ставку"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO bets (match_id, bet_type, predicted_round, amount, odds)
                VALUES (?, ?, ?, ?, ?)
            ''', (match_id, bet_type, predicted_round, amount, odds))
            conn.commit()
            return cursor.lastrowid
        except Exception as e:
            logger.error(f"Ошибка добавления ставки: {e}")
            return None
        finally:
            conn.close()
    
    def update_bet_result(self, bet_id: int, result: str, won_in_round: Optional[int] = None,
                          profit: float = 0):
        """Обновляет результат ставки"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE bets 
                SET result = ?, won_in_round = ?, profit = ?
                WHERE id = ?
            ''', (result, won_in_round, profit, bet_id))
            conn.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления ставки: {e}")
        finally:
            conn.close()
    
    def get_pending_bets(self) -> List[Dict]:
        """Получает ожидающие ставки"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT * FROM bets WHERE result = 'pending'
            ''')
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения ставок: {e}")
            return []
        finally:
            conn.close()
    
    # === АНАЛИТИЧЕСКИЕ МЕТОДЫ ===
    
    def get_time_pattern_stats(self, hour: int, minute: int) -> Dict:
        """Получает статистику для конкретного времени"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            time_pattern = f"{hour:02d}:{minute:02d}"
            
            cursor.execute('''
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN fatality_round IS NOT NULL THEN 1 ELSE 0 END) as fatalities,
                    SUM(CASE WHEN brutality_round IS NOT NULL THEN 1 ELSE 0 END) as brutalities
                FROM matches
                WHERE strftime('%H:%M', match_time) = ?
                AND result != 'pending'
            ''', (time_pattern,))
            
            row = cursor.fetchone()
            if row and row['total'] > 0:
                total = row['total']
                return {
                    'total_matches': total,
                    'fatality_rate': row['fatalities'] / total * 100,
                    'brutality_rate': row['brutalities'] / total * 100,
                    'any_finish_rate': (row['fatalities'] + row['brutalities']) / total * 100
                }
            return {'total_matches': 0, 'fatality_rate': 0, 'brutality_rate': 0, 'any_finish_rate': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики по времени: {e}")
            return {}
        finally:
            conn.close()
    
    def get_combo_stats(self, executor: str, donor: str) -> Dict:
        """Получает статистику комбинации Палач-Донор"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN fatality_round IS NOT NULL THEN 1 ELSE 0 END) as fatalities,
                    AVG(fatality_round) as avg_fatality_round
                FROM matches
                WHERE ((player1 = ? AND player2 = ?) OR (player1 = ? AND player2 = ?))
                AND result != 'pending'
            ''', (executor, donor, donor, executor))
            
            row = cursor.fetchone()
            if row and row['total'] > 0:
                total = row['total']
                return {
                    'total_matches': total,
                    'fatality_rate': row['fatalities'] / total * 100,
                    'avg_fatality_round': row['avg_fatality_round'] or 0
                }
            return {'total_matches': 0, 'fatality_rate': 0, 'avg_fatality_round': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики комбо: {e}")
            return {}
        finally:
            conn.close()


# Глобальный экземпляр БД
db = MKXDatabase()
